# Changelog

All notable changes to this project will be documented in this file.

## 1.1.0 - 2026-02-05

### Fixed
- **Turret Manual now opens reliably** in both singleplayer and dedicated servers.
  - No longer relies on `ClientboundOpenBookPacket`.
  - Client directly opens the vanilla **BookViewScreen** by copying the manual NBT onto a temporary `minecraft:written_book`.
  - Works when right-clicking air with **main hand / off hand**.

### Improved
- **Turret GUI readability** across different languages and UI scales.
  - Buttons and label texts **auto-scale** to fit their available width (prioritizes full visibility instead of ellipsis).
  - Top info area layout adjusted to avoid overlapping the buttons.
- **New, cleaner GUI texture layout** (panel sections / slot frames / separators unified).
- Minor **localization polish** for en_us / zh_cn / zh_tw / ja_jp to reduce overly-long UI strings.

### Internal
- Added `ManualClientHelper` (client-only manual opening helper).
- Added `FittedTextButton` and scaled-text helpers for consistent UI rendering.

## 1.0.0

### Added
- Initial release of **TurretCraft** for **Minecraft Forge 1.20.1**.
- Multiple turret types (Arrow / Fire / Lightning / Frost / Gatling / Poison / Cannon).
- Ammo loading & unloading via turret GUI.
- Target mode toggle via turret GUI.
- Upgrade system **Lv1 → Lv5** (range / damage multiplier / cooldown / max ammo / ammo-save chance).
- `Turret Firmware` upgrade component (recipe outputs 2).
- In-game Turret Manual with multi-language pages (en_us / zh_cn / zh_tw / ja_jp).
