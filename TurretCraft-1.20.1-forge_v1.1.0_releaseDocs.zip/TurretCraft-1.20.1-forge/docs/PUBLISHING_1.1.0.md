# TurretCraft 1.1.0 (Forge 1.20.1) — Publishing Notes

This document is written to be **copy-pasted** into CurseForge / Modrinth when publishing.

---

## Basic Info
- **Mod Name**: TurretCraft
- **Version**: 1.1.0
- **Loader**: Forge
- **Minecraft**: 1.20.1
- **Java**: 17
- **Dependencies**: **None** (zero required mods)
- **License**: MIT (see `LICENSE`)

---

## Short Summary (one-liner)
**TurretCraft adds upgradeable defensive turrets (Lv1–Lv5) with ammo loading, target toggles, and an in-game manual — perfect for base defense and wave-survival gameplay.**

---

## Description (English)
TurretCraft is an upgradeable turret defense mod for Minecraft Forge 1.20.1.
Place turrets like blocks, load ammo through a GUI, toggle target mode, and upgrade turrets from **Lv1 to Lv5** to improve range, damage multiplier, fire rate, max ammo, and ammo-save chance.

### Core Features
- Multiple turret types (Arrow / Fire / Lightning / Frost / Gatling / Poison / Cannon)
- Ammo loading & unloading via GUI
- Toggle target mode (e.g., Mobs / Players)
- Upgrade system (**Lv1 → Lv5**) with clear material requirements and upgrade success SFX
- In-game manual with multi-language pages (en_us / zh_cn / zh_tw / ja_jp)

---

## Description (中文简体)
TurretCraft 是一个可升级的炮台防御模组（Minecraft Forge 1.20.1）。
你可以放置不同类型的炮台，通过 GUI 装填弹药、切换目标模式、卸载弹药，并将炮台从 **Lv1 升级到 Lv5**，全面提升射程、伤害倍率、射速（冷却）、最大弹药与省弹概率。

### 核心特性
- 多种炮台：箭矢 / 火焰 / 雷电 / 冰霜 / 加特林 / 剧毒 / 大炮
- GUI 装填/卸载弹药
- GUI 切换目标模式（怪物 / 玩家等）
- 升级系统（Lv1 → Lv5）：材料需求清晰，升级成功音效反馈
- 游戏内说明书：支持 en_us / zh_cn / zh_tw / ja_jp 多语言页面

---

## Release Notes — 1.1.0
(Also available in `CHANGELOG.md`)

### Fixed
- **Turret Manual** now opens reliably in both singleplayer and dedicated servers.
  - Client opens vanilla **BookViewScreen** using a temporary `minecraft:written_book` that copies the manual NBT.

### Improved
- **Turret GUI** readability across different languages and UI scales.
  - Buttons/labels auto-scale so text remains fully visible and does not overlap other UI.
- New, cleaner GUI texture layout.
- Minor localization polish (en_us / zh_cn / zh_tw / ja_jp).

---

## Compatibility & Installation
- Put the mod **JAR** into your `mods` folder.
- This mod adds blocks/items/GUI, so it is **required on both client and server**.

---

## Known Notes
- Some GUI elements may still be purely visual placeholders (future roadmap items are documented in `README.md`).
- If an old manual item ever shows outdated pages, re-craft/re-get the manual to regenerate its NBT.

---

## Support
- If you hit an issue, please include:
  - Minecraft version + Forge version
  - Mod version
  - Logs (`latest.log`) and steps to reproduce
