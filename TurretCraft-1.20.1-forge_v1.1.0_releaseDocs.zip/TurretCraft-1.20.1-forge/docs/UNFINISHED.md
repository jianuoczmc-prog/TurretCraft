# TurretCraft - UNFINISHED / TO CONFIRM

This file lists items that are **not yet finalized** (may need your decision) or are **planned**.

## ✅ Implemented in this build
- Turret level system: **Lv1 → Lv5**
- Smooth upgrade cost curve (early levels use fewer item types)
- Upgrade slots + Upgrade button + detailed tooltip
- Upgrade success sound
- "Turret Firmware" item + recipe output **2**
- Updated GUI texture (v3) + correct rendering (uses the real 176x202 texture size)
- In-game manual (en_us / zh_cn / zh_tw / ja_jp) expanded to 14 pages
- Manual item auto-refresh: old manual items regenerate pages to match the current version

## 🔧 Needs balancing / confirmation (easy to adjust)
- Final upgrade numbers (iron/redstone/gold/diamond/netherite/firmware) if you want harder or easier survival.
- Per-turret stat scaling (damage / cooldown / range) for each turret kind (currently uses a shared curve).

## 🚧 Planned / not implemented yet
- Per-level **turret appearance changes** (visual upgrades)
- GUI progress bars (cooldown / ammo) + richer stat panel (range/damage/cooldown/DPS)
- Server config file for balancing (damage/range/upgrade costs)
- Per-turret independent balance tables
- Visual upgrade effects (appearance changes, particles)
