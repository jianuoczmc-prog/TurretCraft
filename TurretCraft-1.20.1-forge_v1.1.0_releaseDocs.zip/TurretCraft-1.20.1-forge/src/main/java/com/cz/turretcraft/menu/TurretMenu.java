package com.cz.turretcraft.menu;

import com.cz.turretcraft.block.TurretKind;
import com.cz.turretcraft.blockentity.TurretBlockEntity;
import com.cz.turretcraft.registry.ModMenus;
import com.cz.turretcraft.upgrade.TurretUpgrades;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.network.chat.Component;
import net.minecraft.world.Container;
import net.minecraft.world.SimpleContainer;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.ContainerData;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;
import net.minecraftforge.items.IItemHandler;
import net.minecraftforge.items.SlotItemHandler;

import java.util.List;

public class TurretMenu extends AbstractContainerMenu {
    private final TurretBlockEntity turret;
    private final Level level;

    /**
     * Client-synced values from {@link #data}. We must NOT read live values directly from the client BE,
     * otherwise the GUI can look "stuck" after upgrades until the BE packet arrives.
     */
    private final int[] synced = new int[5];

    // GUI-only containers
    private final Container ammoInput = new SimpleContainer(1) {
        @Override
        public void setChanged() {
            super.setChanged();
            // Auto-load ammo into internal storage (server-side only to avoid client ghost items)
            if (TurretMenu.this.level == null || TurretMenu.this.level.isClientSide) return;
            ItemStack stack = this.getItem(0);
            if (!stack.isEmpty()) {
                int moved = turret.addAmmoFromStack(stack);
                if (moved > 0) {
                    // stack is shrunk by addAmmoFromStack
                    if (stack.isEmpty()) this.setItem(0, ItemStack.EMPTY);
                }
            }
        }
    };

    /** Upgrade material slots (6). */
    private final Container upgradeInput = new SimpleContainer(6);

    // data slots:
    // 0 ammo
    // 1 targetPlayers (0/1)
    // 2 turretKind ordinal
    // 3 upgradeLevel
    // 4 cooldownTicks (remaining)
    private final ContainerData data;

    public TurretMenu(int id, Inventory inv, TurretBlockEntity turret) {
        super(ModMenus.TURRET_MENU.get(), id);
        this.turret = turret;
        this.level = inv.player.level();

        this.data = new ContainerData() {
            @Override public int get(int index) {
                // Client must read from synced[] (updated by set()).
                if (TurretMenu.this.level != null && TurretMenu.this.level.isClientSide) {
                    return (index >= 0 && index < synced.length) ? synced[index] : 0;
                }
                return serverValue(index);
            }

            @Override public void set(int index, int value) {
                // Called on the client when the server syncs ContainerData.
                if (index >= 0 && index < synced.length) synced[index] = value;
            }

            @Override public int getCount() { return synced.length; }
        };
        addDataSlots(this.data);

        // Initialize client-side values to something sane before the first sync packet arrives.
        if (this.level != null && this.level.isClientSide) {
            for (int i = 0; i < synced.length; i++) synced[i] = serverValue(i);
        }

        // --------- Turret GUI slots ----------
        // Ammo input slot (player puts ammo here; it auto-loads)
        // v4 GUI: ammo slot top-right
        this.addSlot(new Slot(ammoInput, 0, 135, 19) {
            @Override
            public boolean mayPlace(ItemStack stack) {
                return turret.isValidAmmo(stack);
            }
        });

        // Upgrade slots (v4 GUI): right-middle 2x3
        // We keep the logical slot mapping (see TurretUpgrades) but place Firmware on the top row for convenience.
        addUpgradeSlot(0, 90, 70);   // iron
        addUpgradeSlot(5, 108, 70);  // firmware
        addUpgradeSlot(1, 126, 70);  // redstone
        addUpgradeSlot(2, 90, 88);   // gold
        addUpgradeSlot(3, 108, 88);  // diamond
        addUpgradeSlot(4, 126, 88);  // netherite scrap

        // --------- Player inventory ----------
        // Player inventory slots (v4 GUI)
        // Align to the slot grid in turret_gui_v4.png (the drawn borders).
        addPlayerInventory(inv, 121);
        addPlayerHotbar(inv, 179);

    }


/**
 * Client-side constructor used by the MenuType factory (reads BlockPos from network).
 * Tries to resolve the turret block entity from the client world.
 */
public TurretMenu(int id, Inventory inv, BlockPos pos) {
    this(id, inv, resolveTurret(inv, pos));
}

private static TurretBlockEntity resolveTurret(Inventory inv, BlockPos pos) {
    Level level = inv.player.level();
    BlockEntity be = level.getBlockEntity(pos);
    if (be instanceof TurretBlockEntity t) return t;
    // Fallback: should be rare (chunk not ready). Use a minimal dummy so the GUI won't crash.
    return new TurretBlockEntity(pos, com.cz.turretcraft.registry.ModBlocks.ARROW_TURRET.get().defaultBlockState());
}

    private void addUpgradeSlot(int index, int x, int y) {
        Item must = TurretUpgrades.slotItem(index);
        this.addSlot(new Slot(upgradeInput, index, x, y) {
            @Override
            public boolean mayPlace(ItemStack stack) {
                return !stack.isEmpty() && stack.is(must);
            }

            @Override
            public int getMaxStackSize() {
                return 64;
            }
        });
    }

    private void addPlayerInventory(Inventory inv, int startY) {
        for (int row = 0; row < 3; ++row) {
            for (int col = 0; col < 9; ++col) {
                this.addSlot(new Slot(inv, col + row * 9 + 9, 9 + col * 18, startY + row * 18));
            }
        }
    }

    private void addPlayerHotbar(Inventory inv, int y) {
        for (int col = 0; col < 9; ++col) {
            this.addSlot(new Slot(inv, col, 9 + col * 18, y));
        }
    }

    public int getAmmo() {
        return data.get(0);
    }

    public boolean isTargetPlayers() {
        return data.get(1) == 1;
    }

    public TurretKind getTurretKind() {
        int ord = data.get(2);
        TurretKind[] values = TurretKind.values();
        if (ord < 0 || ord >= values.length) return TurretKind.ARROW;
        return values[ord];
    }

    public int getUpgradeLevel() {
        int lvl = data.get(3);
        return TurretUpgrades.clampLevel(lvl);
    }

    public int getCooldownTicks() {
        return data.get(4);
    }

    public int getMaxAmmo() {
        return TurretUpgrades.maxAmmo(getUpgradeLevel());
    }

    public int getEffectiveRange() {
        TurretKind kind = getTurretKind();
        return kind.range() + TurretUpgrades.rangeBonus(getUpgradeLevel());
    }

    public int getEffectiveCooldownTicks() {
        TurretKind kind = getTurretKind();
        return Math.max(1, Math.round(kind.cooldownTicks() * TurretUpgrades.cooldownMultiplier(getUpgradeLevel())));
    }

    public float getDamageMultiplier() {
        return TurretUpgrades.damageMultiplier(getUpgradeLevel());
    }

    public float getAmmoSaveChance() {
        return TurretUpgrades.ammoSaveChance(getUpgradeLevel());
    }

    private int serverValue(int index) {
        return switch (index) {
            case 0 -> turret.getAmmo();
            case 1 -> turret.isTargetPlayers() ? 1 : 0;
            case 2 -> turret.kind().ordinal();
            case 3 -> turret.getUpgradeLevel();
            case 4 -> turret.getCooldownTicks();
            default -> 0;
        };
    }

    public List<TurretUpgrades.Requirement> getNextRequirements() {
        return TurretUpgrades.requirementsForNextLevel(getUpgradeLevel());
    }

    public Container getUpgradeContainer() {
        return upgradeInput;
    }

    @Override
    public boolean clickMenuButton(Player player, int id) {
        // Called on server
        if (player.level().isClientSide) return true;

        if (id == 0) {
            if (!turret.isOwner(player)) {
                player.displayClientMessage(Component.translatable("msg.turretcraft.upgrade.not_owner"), false);
                return true;
            }
            turret.toggleTargetPlayers();
            turret.setChanged();
            return true;
        }

        if (id == 1) {
            // Unload ammo back to player
            if (!turret.isOwner(player)) {
                player.displayClientMessage(Component.translatable("msg.turretcraft.upgrade.not_owner"), false);
                return true;
            }
            int amount = turret.getAmmo();
            if (amount <= 0) return true;

            ItemStack ammoStack = turret.createAmmoStack(amount);
            turret.setAmmo(0);
            turret.setChanged();

            if (!player.addItem(ammoStack)) {
                player.drop(ammoStack, false);
            }
            player.displayClientMessage(Component.translatable("message.turretcraft.ammo_unloaded"), true);
            return true;
        }

        if (id == 2) {
            // Upgrade
            if (!turret.isOwner(player)) {
                player.displayClientMessage(Component.translatable("msg.turretcraft.upgrade.not_owner"), false);
                return true;
            }
            int current = turret.getUpgradeLevel();
            if (current >= TurretUpgrades.MAX_LEVEL) {
                player.displayClientMessage(Component.translatable("msg.turretcraft.upgrade.max_level", TurretUpgrades.MAX_LEVEL), false);
                return true;
            }

            List<TurretUpgrades.Requirement> req = TurretUpgrades.requirementsForNextLevel(current);
            if (req.isEmpty()) {
                player.displayClientMessage(Component.translatable("msg.turretcraft.upgrade.max_level", TurretUpgrades.MAX_LEVEL), false);
                return true;
            }

            boolean ok = true;
            player.displayClientMessage(Component.translatable("msg.turretcraft.upgrade.requirements_title", current, current + 1), false);

            // We'll print each needed line with have/need.
            for (TurretUpgrades.Requirement r : req) {
                int have = countInUpgradeSlots(r.item());
                int need = r.count();
                int missing = Math.max(0, need - have);
                if (missing > 0) ok = false;

                player.displayClientMessage(Component.translatable(
                        "msg.turretcraft.upgrade.missing_line",
                        Component.translatable(r.item().getDescriptionId()),
                        need, have, missing
                ), false);
            }

            if (!ok) {
                player.displayClientMessage(Component.translatable("msg.turretcraft.upgrade.fail", current, current + 1), false);
                return true;
            }

            // Consume items per requirement.
            for (TurretUpgrades.Requirement r : req) {
                consumeFromUpgradeSlots(r.item(), r.count());
            }

            // Apply upgrade
            int oldLevel = current;
            turret.setUpgradeLevel(current + 1);
            turret.applyUpgradeSuccess(level, turret.getBlockPos(), player, turret.getUpgradeLevel());

            // Detailed stats comparison (chat)
            int newLevel = turret.getUpgradeLevel();
            TurretKind kind = turret.kind();

            int oldMaxAmmo = TurretUpgrades.maxAmmo(oldLevel);
            int newMaxAmmo = TurretUpgrades.maxAmmo(newLevel);

            int oldRange = kind.range() + TurretUpgrades.rangeBonus(oldLevel);
            int newRange = kind.range() + TurretUpgrades.rangeBonus(newLevel);

            float oldDmg = kind.damage() * TurretUpgrades.damageMultiplier(oldLevel);
            float newDmg = kind.damage() * TurretUpgrades.damageMultiplier(newLevel);

            int oldCd = Math.max(1, Math.round(kind.cooldownTicks() * TurretUpgrades.cooldownMultiplier(oldLevel)));
            int newCd = Math.max(1, Math.round(kind.cooldownTicks() * TurretUpgrades.cooldownMultiplier(newLevel)));

            float oldSave = TurretUpgrades.ammoSaveChance(oldLevel) * 100.0F;
            float newSave = TurretUpgrades.ammoSaveChance(newLevel) * 100.0F;

            player.displayClientMessage(Component.translatable("msg.turretcraft.upgrade.stats_title"), false);
            player.displayClientMessage(Component.translatable("msg.turretcraft.upgrade.stat_max_ammo", oldMaxAmmo, newMaxAmmo), false);
            player.displayClientMessage(Component.translatable("msg.turretcraft.upgrade.stat_range", oldRange, newRange), false);
            player.displayClientMessage(Component.translatable("msg.turretcraft.upgrade.stat_damage", String.format("%.2f", oldDmg), String.format("%.2f", newDmg)), false);
            player.displayClientMessage(Component.translatable("msg.turretcraft.upgrade.stat_cooldown", oldCd, newCd), false);
            player.displayClientMessage(Component.translatable("msg.turretcraft.upgrade.stat_save", String.format("%.0f%%", oldSave), String.format("%.0f%%", newSave)), false);

            turret.setChanged();
            return true;
        }

        return super.clickMenuButton(player, id);
    }

    private int countInUpgradeSlots(Item item) {
        int total = 0;
        for (int i = 0; i < upgradeInput.getContainerSize(); i++) {
            ItemStack s = upgradeInput.getItem(i);
            if (!s.isEmpty() && s.is(item)) total += s.getCount();
        }
        return total;
    }

    private void consumeFromUpgradeSlots(Item item, int amount) {
        int remaining = amount;
        for (int i = 0; i < upgradeInput.getContainerSize(); i++) {
            if (remaining <= 0) return;
            ItemStack s = upgradeInput.getItem(i);
            if (s.isEmpty() || !s.is(item)) continue;

            int take = Math.min(remaining, s.getCount());
            s.shrink(take);
            remaining -= take;
            if (s.isEmpty()) upgradeInput.setItem(i, ItemStack.EMPTY);
        }
    }

    @Override
    public ItemStack quickMoveStack(Player player, int index) {
        ItemStack itemstack = ItemStack.EMPTY;
        Slot slot = this.slots.get(index);
        if (slot == null || !slot.hasItem()) return ItemStack.EMPTY;

        ItemStack stack = slot.getItem();
        itemstack = stack.copy();

        // Slot indices:
        // 0 ammoInput
        // 1-6 upgradeInput
        // 7.. = player inventory+hotbar
        int AMMO_SLOT = 0;
        int UPGRADE_START = 1;
        int UPGRADE_END_EXCL = 7;
        int PLAYER_START = 7;
        int PLAYER_END_EXCL = this.slots.size();

        if (index >= PLAYER_START) {
            // from player -> turret GUI
            if (turret.isValidAmmo(stack)) {
                if (!this.moveItemStackTo(stack, AMMO_SLOT, AMMO_SLOT + 1, false)) {
                    return ItemStack.EMPTY;
                }
            } else {
                int slotId = TurretUpgrades.slotForItem(stack);
                if (slotId >= 0) {
                    int targetIndex = UPGRADE_START + slotId;
                    if (!this.moveItemStackTo(stack, targetIndex, targetIndex + 1, false)) {
                        return ItemStack.EMPTY;
                    }
                } else {
                    return ItemStack.EMPTY;
                }
            }
        } else {
            // from turret GUI -> player
            if (!this.moveItemStackTo(stack, PLAYER_START, PLAYER_END_EXCL, true)) {
                return ItemStack.EMPTY;
            }
        }

        if (stack.isEmpty()) {
            slot.set(ItemStack.EMPTY);
        } else {
            slot.setChanged();
        }

        return itemstack;
    }

    @Override
    public void removed(Player player) {
        super.removed(player);
        // Return items from GUI containers to player
        if (!player.level().isClientSide) {
            clearContainer(player, ammoInput);
            clearContainer(player, upgradeInput);
        }
    }

    @Override
    public boolean stillValid(Player player) {
        return turret != null && !turret.isRemoved() && player.distanceToSqr(
                turret.getBlockPos().getX() + 0.5,
                turret.getBlockPos().getY() + 0.5,
                turret.getBlockPos().getZ() + 0.5
        ) <= 64.0;
    }
}
