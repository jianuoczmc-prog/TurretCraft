package com.cz.turretcraft.block;

import com.cz.turretcraft.registry.ModItems;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.Items;

import java.util.function.Supplier;

public enum TurretKind {
    ARROW(() -> Items.ARROW, 16, 20, 4.0F),
    FIRE(() -> Items.BLAZE_POWDER, 14, 30, 5.0F),
    LIGHTNING(() -> Items.AMETHYST_SHARD, 18, 60, 6.0F),
    FROST(() -> ModItems.FROST_SHARD.get(), 16, 20, 3.0F),

    // High rate-of-fire, low damage.
    GATLING(() -> ModItems.IRON_BULLET.get(), 18, 4, 1.5F),
    // Applies poison on hit.
    POISON(() -> ModItems.POISON_DART.get(), 16, 18, 2.5F),
    // AOE explosion damage (no block damage).
    CANNON(() -> ModItems.CANNONBALL.get(), 22, 50, 7.0F);

    private final Supplier<Item> ammoItem;
    private final int range;
    private final int cooldownTicks;
    private final float damage;

    TurretKind(Supplier<Item> ammoItem, int range, int cooldownTicks, float damage) {
        this.ammoItem = ammoItem;
        this.range = range;
        this.cooldownTicks = cooldownTicks;
        this.damage = damage;
    }

    public Item ammoItem() {
        return ammoItem.get();
    }

    public int range() {
        return range;
    }

    public int cooldownTicks() {
        return cooldownTicks;
    }

    public float damage() {
        return damage;
    }
}
