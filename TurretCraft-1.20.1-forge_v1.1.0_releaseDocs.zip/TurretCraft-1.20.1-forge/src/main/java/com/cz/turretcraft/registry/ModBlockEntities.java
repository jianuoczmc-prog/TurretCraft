package com.cz.turretcraft.registry;

import com.cz.turretcraft.TurretCraft;
import com.cz.turretcraft.blockentity.TurretBlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModBlockEntities {
    public static final DeferredRegister<BlockEntityType<?>> BLOCK_ENTITIES = DeferredRegister.create(ForgeRegistries.BLOCK_ENTITY_TYPES, TurretCraft.MODID);

    public static final RegistryObject<BlockEntityType<TurretBlockEntity>> TURRET = BLOCK_ENTITIES.register(
            "turret",
            () -> BlockEntityType.Builder.of(TurretBlockEntity::new,
                    ModBlocks.ARROW_TURRET.get(),
                    ModBlocks.FIRE_TURRET.get(),
                    ModBlocks.LIGHTNING_TURRET.get(),
                    ModBlocks.FROST_TURRET.get(),
                    ModBlocks.GATLING_TURRET.get(),
                    ModBlocks.POISON_TURRET.get(),
                    ModBlocks.CANNON_TURRET.get()
            ).build(null)
    );
}
