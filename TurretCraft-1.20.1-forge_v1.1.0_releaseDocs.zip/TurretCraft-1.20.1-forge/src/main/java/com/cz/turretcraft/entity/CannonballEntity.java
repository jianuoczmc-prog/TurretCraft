package com.cz.turretcraft.entity;

import com.cz.turretcraft.registry.ModItems;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.projectile.ThrowableItemProjectile;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.EntityHitResult;

/**
 * Cannonball projectile that explodes on impact.
 */
public class CannonballEntity extends ThrowableItemProjectile {

    private static final EntityDataAccessor<Float> POWER = SynchedEntityData.defineId(CannonballEntity.class, EntityDataSerializers.FLOAT);

    public CannonballEntity(EntityType<? extends CannonballEntity> type, Level level) {
        super(type, level);
    }

    @Override
    protected void defineSynchedData() {
        super.defineSynchedData();
        this.entityData.define(POWER, 2.2F);
    }

    @Override
    protected Item getDefaultItem() {
        return ModItems.CANNONBALL.get();
    }

    @Override
    protected float getGravity() {
        return 0.05F;
    }

    public void setExplosionPower(float power) {
        this.entityData.set(POWER, power);
    }

    public float getExplosionPower() {
        return this.entityData.get(POWER);
    }

    @Override
    public void tick() {
        super.tick();

        if (this.level().isClientSide) {
            this.level().addParticle(ParticleTypes.SMOKE, this.getX(), this.getY(), this.getZ(), 0.0, 0.0, 0.0);
        }

        if (this.tickCount > 120) {
            this.discard();
        }
    }

    @Override
    protected void onHitEntity(EntityHitResult hit) {
        super.onHitEntity(hit);
        explode();
    }

    @Override
    protected void onHitBlock(BlockHitResult hit) {
        super.onHitBlock(hit);
        explode();
    }

    private void explode() {
        if (!this.level().isClientSide) {
            float power = getExplosionPower();
            this.level().explode(this, this.getX(), this.getY(), this.getZ(), power, Level.ExplosionInteraction.MOB);
        }
        this.discard();
    }


@Override
public net.minecraft.network.protocol.Packet<net.minecraft.network.protocol.game.ClientGamePacketListener> getAddEntityPacket() {
    return net.minecraftforge.network.NetworkHooks.getEntitySpawningPacket(this);
}
}
