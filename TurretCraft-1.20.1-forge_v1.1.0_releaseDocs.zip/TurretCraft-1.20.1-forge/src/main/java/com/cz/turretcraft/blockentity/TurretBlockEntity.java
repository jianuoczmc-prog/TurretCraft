package com.cz.turretcraft.blockentity;

import com.cz.turretcraft.TurretCraft;
import com.cz.turretcraft.block.TurretBlock;
import com.cz.turretcraft.block.TurretKind;
import com.cz.turretcraft.entity.CannonballEntity;
import com.cz.turretcraft.entity.FrostShardEntity;
import com.cz.turretcraft.entity.IronBulletEntity;
import com.cz.turretcraft.registry.ModBlockEntities;
import com.cz.turretcraft.registry.ModEntities;
import com.cz.turretcraft.registry.ModItems;
import com.cz.turretcraft.upgrade.TurretUpgrades;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.Connection;
import net.minecraft.network.chat.Component;
import net.minecraft.network.protocol.game.ClientboundBlockEntityDataPacket;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.EntitySelector;
import net.minecraft.world.entity.LightningBolt;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.AbstractArrow;
import net.minecraft.world.entity.projectile.Arrow;
import net.minecraft.world.entity.projectile.SmallFireball;
import net.minecraft.world.entity.projectile.SpectralArrow;
import net.minecraft.world.entity.projectile.ThrownPotion;
import net.minecraft.world.item.ArrowItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.common.util.LazyOptional;
import net.minecraftforge.items.ItemStackHandler;
import org.jetbrains.annotations.Nullable;

import java.util.List;
import java.util.UUID;

/**
 * Turret block entity.
 *
 * Stores:
 * - ammo count + ammo template (arrow variant etc.)
 * - targeting mode + owner/team
 * - current yaw/pitch for visuals
 * - upgrade level (1..5)
 */
public class TurretBlockEntity extends BlockEntity implements net.minecraft.world.MenuProvider {
    /** Upgrade scaling uses a base max of 256. */
    private static final int BASE_MAX_AMMO = 256;

    // Ammo storage is internal (count + template), but GUI also has an input slot.
    private int ammo = 0;
    private ItemStack ammoTemplate = ItemStack.EMPTY;

    private boolean targetPlayers = false;

    // Owner & team
    private @Nullable UUID owner;
    private @Nullable String teamName;

    // Visual state
    private float turretYaw = 0;
    private float turretPitch = 0;

    // Recoil (for barrel kick)
    private float turretRecoil = 0;

    // Client-side interpolation helpers
    private float prevYaw = 0;
    private float prevPitch = 0;
    private float prevRecoil = 0;

    // Client-only visual aiming
    // (Server does not send yaw/pitch every tick; the client recomputes visuals locally.)
    private int clientAimTicker = 0;
    private boolean clientAimInit = false;
    private float clientDesiredYaw = 0.0F;
    private float clientDesiredPitch = 0.0F;

    // Server firing cooldown (ticks)
    private int cooldownTicks = 0;

    // Upgrade level (1..5)
    private int upgradeLevel = 1;

    // GUI inventory for ammo insertion
    private final ItemStackHandler itemHandler = new ItemStackHandler(1) {
        @Override
        protected void onContentsChanged(int slot) {
            setChanged();
        }

        @Override
        public boolean isItemValid(int slot, ItemStack stack) {
            return isValidAmmo(stack);
        }

        @Override
        public int getSlotLimit(int slot) {
            return 64;
        }
    };

    private final LazyOptional<ItemStackHandler> lazyItemHandler = LazyOptional.of(() -> itemHandler);

    public TurretBlockEntity(BlockPos pos, BlockState state) {
        super(ModBlockEntities.TURRET.get(), pos, state);
    }

    // ----------------------------
    // Accessors
    // ----------------------------

    public int getAmmo() {
        return ammo;
    }

    /** Remaining firing cooldown in ticks (0 = ready). Synced to the GUI via menu data slots. */
    public int getCooldownTicks() {
        return cooldownTicks;
    }

    public void setAmmo(int ammo) {
        this.ammo = Mth.clamp(ammo, 0, getMaxAmmo());
    }

    public boolean isTargetPlayers() {
        return targetPlayers;
    }

    public void toggleTargetPlayers() {
        this.targetPlayers = !this.targetPlayers;
    }

    public float getTurretYaw() {
        return turretYaw;
    }

    public float getTurretPitch() {
        return turretPitch;
    }

    public int getUpgradeLevel() {
        return upgradeLevel;
    }

    public void setUpgradeLevel(int level) {
        this.upgradeLevel = TurretUpgrades.clampLevel(level);
        // Clamp ammo after level changes
        this.ammo = Mth.clamp(this.ammo, 0, getMaxAmmo());
        setChanged();
    }

    public int getMaxAmmo() {
        return TurretUpgrades.maxAmmo(upgradeLevel);
    }

    public int getEffectiveRange() {
        return kind().range() + TurretUpgrades.rangeBonus(upgradeLevel);
    }

    public int getEffectiveCooldownTicks() {
        int base = kind().cooldownTicks();
        return Math.max(1, Math.round(base * TurretUpgrades.cooldownMultiplier(upgradeLevel)));
    }

    public float getEffectiveDamage() {
        return kind().damage() * TurretUpgrades.damageMultiplier(upgradeLevel);
    }

    public float getAmmoSaveChance() {
        return TurretUpgrades.ammoSaveChance(upgradeLevel);
    }

    public boolean isOwner(Player player) {
        return owner == null || owner.equals(player.getUUID());
    }

    public void setOwner(UUID owner, @Nullable String teamName) {
        this.owner = owner;
        this.teamName = teamName;
    }

    public @Nullable UUID getOwner() {
        return owner;
    }

    public @Nullable String getTeamName() {
        return teamName;
    }

    public TurretKind kind() {
        if (this.level == null) return TurretKind.ARROW;
        BlockState state = getBlockState();
        if (state.getBlock() instanceof TurretBlock tb) {
            return tb.getKind();
        }
        return TurretKind.ARROW;
    }

/**
 * Renderer helper: kept for compatibility with the rotating head/barrel renderer.
 */
public TurretKind getKind() {
    return kind();
}

public float renderYaw(float partialTick) {
    return Mth.lerp(partialTick, prevYaw, turretYaw);
}

public float renderPitch(float partialTick) {
    return Mth.lerp(partialTick, prevPitch, turretPitch);
}

public float renderRecoil(float partialTick) {
    return Mth.lerp(partialTick, prevRecoil, turretRecoil);
}


    // ----------------------------
    // Ammo helpers
    // ----------------------------

    public boolean isValidAmmo(ItemStack stack) {
        TurretKind kind = kind();

        if (kind == TurretKind.ARROW || kind == TurretKind.POISON) {
            // Accept ArrowItem variants (normal/tipped/spectral), but only one type at a time.
            return stack.getItem() instanceof ArrowItem;
        }

        // Other turrets accept a specific item (including our custom ones).
        Item ammoItem = kind.ammoItem();
        return stack.is(ammoItem);
    }

    /** If arrow-type turret, ensure only one arrow item variant is loaded at a time. */
    private boolean canAcceptAmmoTemplate(ItemStack stack) {
        TurretKind kind = kind();
        if (kind == TurretKind.ARROW || kind == TurretKind.POISON) {
            if (!(stack.getItem() instanceof ArrowItem)) return false;
            if (ammoTemplate.isEmpty()) return true;
            return ItemStack.isSameItemSameTags(ammoTemplate, stack);
        }
        // For non-arrow turrets: no NBT variants.
        return true;
    }

    public int addAmmoFromStack(ItemStack stack) {
        if (stack.isEmpty()) return 0;
        if (!isValidAmmo(stack)) return 0;

        int maxAmmo = getMaxAmmo();
        if (ammo >= maxAmmo) return 0;

        if (!canAcceptAmmoTemplate(stack)) return 0;

        int canTake = Math.min(stack.getCount(), maxAmmo - ammo);

        // Set template if empty
        if (ammoTemplate.isEmpty()) {
            ammoTemplate = stack.copy();
            ammoTemplate.setCount(1);
        }

        ammo += canTake;
        stack.shrink(canTake);
        setChanged();
        return canTake;
    }

    public void clearAmmoTemplateIfEmpty() {
        if (ammo <= 0) {
            ammoTemplate = ItemStack.EMPTY;
        }
    }

    /** Create an ammo stack with correct type (for unloading). */
    public ItemStack createAmmoStack(int count) {
        TurretKind kind = kind();
        if (kind == TurretKind.ARROW || kind == TurretKind.POISON) {
            if (ammoTemplate.isEmpty()) {
                return new ItemStack(Items.ARROW, count);
            }
            ItemStack out = ammoTemplate.copy();
            out.setCount(count);
            return out;
        }
        // For other turrets, template is not important.
        return new ItemStack(kind.ammoItem(), count);
    }

    // ----------------------------
    // Ticking
    // ----------------------------

    /**
     * Pull ammo from the GUI input slot into the internal ammo counter.
     *
     * Why: players may insert ammo into the slot, but if something goes wrong
     * with client->server syncing, the turret could end up with 0 internal ammo
     * and never fire. Doing a cheap pull every server tick guarantees the turret
     * will start firing as long as there is valid ammo in the slot.
     */
    private void absorbAmmoFromInputSlot() {
        ItemStack stack = itemHandler.getStackInSlot(0);
        if (stack.isEmpty()) return;
        if (!isValidAmmo(stack)) return;

        int before = stack.getCount();
        int taken = addAmmoFromStack(stack); // shrinks the same stack instance
        if (taken > 0 && stack.getCount() != before) {
            // Ensure handler is updated so the GUI sees the reduced stack.
            itemHandler.setStackInSlot(0, stack);
        }
    }

    public static void serverTick(Level level, BlockPos pos, BlockState state, TurretBlockEntity turret) {
        if (turret.cooldownTicks > 0) turret.cooldownTicks--;

        // Always try to pull ammo from the GUI slot into internal storage.
        turret.absorbAmmoFromInputSlot();

        // Recoil decay
        turret.turretRecoil = Math.max(0.0F, turret.turretRecoil - 0.03F);

        // Keep internal ammo template consistent
        if (turret.ammo <= 0) turret.clearAmmoTemplateIfEmpty();

        if (turret.ammo <= 0) return;

        TurretKind kind = turret.kind();
        int range = turret.getEffectiveRange();

        // Find targets in sphere-like AABB (actual targeting uses distance check).
        AABB box = new AABB(pos).inflate(range);

        List<LivingEntity> candidates = level.getEntitiesOfClass(LivingEntity.class, box, e -> {
            if (!EntitySelector.NO_SPECTATORS.test(e)) return false;
            if (!e.isAlive()) return false;
            if (e.isInvulnerable()) return false;
            if (e.isRemoved()) return false;

            // Don't target the owner.
            if (turret.owner != null && e.getUUID().equals(turret.owner)) return false;

            // Target rules
            if (turret.targetPlayers) {
                if (!(e instanceof Player)) return false;
                // Don't target teammates
                if (turret.teamName != null && e.getTeam() != null && turret.teamName.equals(e.getTeam().getName())) {
                    return false;
                }
            } else {
                // Hostiles only (no passive mobs, no players)
                if (e instanceof Player) return false;
                // Use Enemy so we also include non-Monster hostiles (e.g., Shulker, etc.)
                if (!(e instanceof net.minecraft.world.entity.monster.Enemy)) return false;
            }

            // Distance within sphere
            double dx = e.getX() - (pos.getX() + 0.5);
            double dy = e.getY() + e.getBbHeight() * 0.5 - (pos.getY() + 0.8);
            double dz = e.getZ() - (pos.getZ() + 0.5);
            return (dx * dx + dy * dy + dz * dz) <= (range * range);
        });

        if (candidates.isEmpty()) return;

        // Choose closest
        LivingEntity target = candidates.get(0);
        double best = target.distanceToSqr(pos.getX() + 0.5, pos.getY() + 0.8, pos.getZ() + 0.5);
        for (int i = 1; i < candidates.size(); i++) {
            LivingEntity e = candidates.get(i);
            double d = e.distanceToSqr(pos.getX() + 0.5, pos.getY() + 0.8, pos.getZ() + 0.5);
            if (d < best) {
                best = d;
                target = e;
            }
        }

        // Aim
        Vec3 from = new Vec3(pos.getX() + 0.5, pos.getY() + 0.8, pos.getZ() + 0.5);
        Vec3 to = target.position().add(0, target.getBbHeight() * 0.5, 0);
        Vec3 dir = to.subtract(from).normalize();

        float yaw = (float) (Mth.atan2(dir.z, dir.x) * (180F / Math.PI)) - 90F;
        float pitch = (float) (-(Mth.atan2(dir.y, Math.sqrt(dir.x * dir.x + dir.z * dir.z)) * (180F / Math.PI)));

        turret.turretYaw = yaw;
        turret.turretPitch = pitch;

        if (turret.cooldownTicks > 0) return;

        float damage = turret.getEffectiveDamage();

        // Fire
        switch (kind) {
            case ARROW -> turret.fireArrow(level, pos, dir, damage);
            case FIRE -> turret.fireFire(level, pos, dir, damage);
            case LIGHTNING -> turret.fireLightning(level, pos, target, damage);
            case FROST -> turret.fireFrost(level, pos, dir, damage);
            case GATLING -> turret.fireGatling(level, pos, dir, damage);
            case POISON -> turret.firePoison(level, pos, dir, damage);
            case CANNON -> turret.fireCannon(level, pos, dir, damage);
        }

        // Kick barrel recoil for visuals
        turret.turretRecoil = 0.12F;

        // Consume ammo (with chance to save)
        turret.consumeAmmoAfterShot(level.random);

        turret.cooldownTicks = turret.getEffectiveCooldownTicks();
        turret.setChanged();
    }

    public static void clientTick(Level level, BlockPos pos, BlockState state, TurretBlockEntity turret) {
        if (!level.isClientSide) return;

        // Purely visual: keep previous values for smooth interpolation
        turret.prevYaw = turret.turretYaw;
        turret.prevPitch = turret.turretPitch;
        turret.prevRecoil = turret.turretRecoil;

        // Local recoil decay (client-side)
        turret.turretRecoil = Math.max(0.0F, turret.turretRecoil - 0.03F);

        // Initialize facing-based yaw once so turrets don't start pointing the wrong way.
        // IMPORTANT: also set prevYaw/prevPitch in the same tick to avoid a one-frame 'flash' on placement.
        if (!turret.clientAimInit) {
            Direction facing = state.getValue(TurretBlock.FACING);
            float baseYaw = yawFromFacing(facing);
            turret.turretYaw = baseYaw;
            turret.turretPitch = 0.0F;
            turret.prevYaw = baseYaw;
            turret.prevPitch = 0.0F;
            turret.clientDesiredYaw = baseYaw;
            turret.clientDesiredPitch = 0.0F;
            turret.clientAimInit = true;
            // Let the next ticks handle smoothing/target scan.
            return;
        }

        // Apply smoothing EVERY tick (prevents stutter). We only re-acquire a target every few ticks.
        turret.turretYaw = Mth.approachDegrees(turret.turretYaw, turret.clientDesiredYaw, 10.0F);
        turret.turretPitch = Mth.approachDegrees(turret.turretPitch, turret.clientDesiredPitch, 6.0F);

        // Recompute aiming locally so the rotating head/barrel animation is always present.
        // Do a cheap scan every few ticks.
        turret.clientAimTicker++;
        if ((turret.clientAimTicker % 5) != 0) {
            return;
        }

        int range = turret.getEffectiveRange();
        double r2 = (double) range * (double) range;
        AABB box = new AABB(pos).inflate(range, range, range);
        Vec3 origin = Vec3.atCenterOf(pos).add(0.0, 0.4, 0.0);

        List<LivingEntity> targets = level.getEntitiesOfClass(LivingEntity.class, box, e -> {
            if (!e.isAlive() || e.isInvulnerable()) return false;
            if (e.isRemoved()) return false;
            if (turret.owner != null && e.getUUID().equals(turret.owner)) return false;
            if (e.distanceToSqr(origin) > r2) return false; // spherical range

            if (e instanceof Player p) {
                if (!turret.targetPlayers) return false;
                if (p.isCreative() || p.isSpectator()) return false;
                if (turret.teamName != null && p.getTeam() != null && turret.teamName.equals(p.getTeam().getName())) return false;
                return true;
            }
            return (e instanceof net.minecraft.world.entity.monster.Enemy);
        });

        if (targets.isEmpty()) {
            // Idle: return to block facing direction
            turret.clientDesiredYaw = yawFromFacing(state.getValue(TurretBlock.FACING));
            turret.clientDesiredPitch = 0.0F;
            return;
        }

        LivingEntity target = targets.stream()
                .min(java.util.Comparator.comparingDouble(e -> e.distanceToSqr(origin.x, origin.y, origin.z)))
                .orElse(null);
        if (target == null) return;

        Vec3 to = target.getEyePosition().subtract(origin);
        if (to.lengthSqr() < 1.0E-6) return;

        float desiredYaw = (float) (Mth.atan2(to.x, to.z) * (180.0 / Math.PI));
        double h = Math.sqrt(to.x * to.x + to.z * to.z);
        float desiredPitch = (float) (-Mth.atan2(to.y, h) * (180.0 / Math.PI));
        desiredPitch = Mth.clamp(desiredPitch, -80.0F, 80.0F);

        turret.clientDesiredYaw = desiredYaw;
        turret.clientDesiredPitch = desiredPitch;
}

    private static float yawFromFacing(Direction facing) {
        // Coordinate system: +Z = south, +X = east
        return switch (facing) {
            case SOUTH -> 0.0F;
            case WEST -> 270.0F;
            case NORTH -> 180.0F;
            case EAST -> 90.0F;
            default -> 0.0F;
        };
    }

    private void consumeAmmoAfterShot(RandomSource random) {
        float saveChance = getAmmoSaveChance();
        boolean consume = random.nextFloat() >= saveChance;
        if (consume) {
            ammo = Math.max(0, ammo - 1);
        }
        if (ammo <= 0) clearAmmoTemplateIfEmpty();
    }

    // ----------------------------
    // Fire implementations

/**
 * Compute a stable projectile spawn position.
 *
 * The turret block uses a near-full collision box; spawning at the block center causes many
 * projectiles to collide immediately and appear "stuck on the turret".
 *
 * We spawn slightly ABOVE the turret and forward (horizontally) in the aiming direction.
 * If the turret is placed against a wall, we try shorter offsets to avoid spawning inside a solid block.
 */
private static Vec3 muzzlePos(Level level, BlockPos pos, Vec3 aimDir, double yOff, double forward) {
    Vec3 base = new Vec3(pos.getX() + 0.5, pos.getY() + yOff, pos.getZ() + 0.5);

    // Use FULL aim direction so shots originate and travel from the barrel mouth (including pitch).
    Vec3 d = aimDir;
    if (d.lengthSqr() < 1.0E-6) {
        d = new Vec3(0, 0, 1);
    } else {
        d = d.normalize();
    }

    double f = forward;
    for (int i = 0; i < 6; i++) {
        Vec3 p = base.add(d.scale(f));
        BlockPos bp = BlockPos.containing(p);
        if (level.getBlockState(bp).getCollisionShape(level, bp).isEmpty()) {
            return p;
        }
        // Step back a bit until we find air; avoids spawning inside blocks when turret is against a wall.
        f -= 0.20;
        if (f < 0.35) break;
    }
    return base.add(d.scale(Math.max(0.35, f)));
}

    // ----------------------------

    private void fireArrow(Level level, BlockPos pos, Vec3 dir, float damage) {
    ItemStack template = ammoTemplate.isEmpty() ? new ItemStack(Items.ARROW) : ammoTemplate;

    AbstractArrow arrow;
    Vec3 muzzle = muzzlePos(level, pos, dir, 1.02, 1.05);
    double x = muzzle.x;
    double y = muzzle.y;
    double z = muzzle.z;

    if (template.getItem() == Items.SPECTRAL_ARROW) {
        arrow = new SpectralArrow(level, x, y, z);
    } else if (template.getItem() == Items.TIPPED_ARROW) {
        // 1.20.1: Tipped arrows use Arrow entity; effects are copied from the item.
        Arrow a = new Arrow(level, x, y, z);
        a.setEffectsFromItem(template);
        arrow = a;
    } else if (template.getItem() instanceof ArrowItem ai && template.getItem() != Items.ARROW) {
        // Any other arrow item (modded) - create projectile via ArrowItem
        arrow = ai.createArrow(level, template, null);
        arrow.setPos(x, y, z);
    } else {
        arrow = new Arrow(level, x, y, z);
    }

    arrow.shoot(dir.x, dir.y, dir.z, 2.2F, 1.2F);
    arrow.setBaseDamage(damage);
    arrow.pickup = AbstractArrow.Pickup.DISALLOWED;

    level.addFreshEntity(arrow);
    level.playSound(null, pos, SoundEvents.ARROW_SHOOT, SoundSource.BLOCKS, 0.8F, 1.1F);
}

    private void firePoison(Level level, BlockPos pos, Vec3 dir, float damage) {
        // Poison turret uses arrow projectile but always applies poison.
        Vec3 muzzle = muzzlePos(level, pos, dir, 1.02, 1.05);
        Arrow arrow = new Arrow(level, muzzle.x, muzzle.y, muzzle.z);
arrow.shoot(dir.x, dir.y, dir.z, 2.0F, 1.5F);
        arrow.setBaseDamage(damage);
        arrow.pickup = Arrow.Pickup.DISALLOWED;

        // Poison duration scales slightly with upgrades
        int seconds = 3 + (upgradeLevel - 1);
        arrow.addEffect(new net.minecraft.world.effect.MobEffectInstance(net.minecraft.world.effect.MobEffects.POISON, seconds * 20, 0));

        level.addFreshEntity(arrow);
        level.playSound(null, pos, SoundEvents.ARROW_SHOOT, SoundSource.BLOCKS, 0.8F, 0.95F);
    }

    private void fireFire(Level level, BlockPos pos, Vec3 dir, float damage) {
        Vec3 muzzle = muzzlePos(level, pos, dir, 1.03, 1.12);
        SmallFireball fb = new SmallFireball(level, muzzle.x, muzzle.y, muzzle.z, dir.x, dir.y, dir.z);
        fb.setPos(muzzle.x, muzzle.y, muzzle.z);
        fb.setDeltaMovement(dir.scale(0.9));
level.addFreshEntity(fb);

        // Fire turrets: upgrades increase fire duration by a bit (damage is mostly handled by fireball itself).
        level.playSound(null, pos, SoundEvents.BLAZE_SHOOT, SoundSource.BLOCKS, 0.9F, 1.0F);
    }

    private void fireLightning(Level level, BlockPos pos, LivingEntity target, float damage) {
        LightningBolt bolt = EntityType.LIGHTNING_BOLT.create(level);
        if (bolt == null) return;

        bolt.moveTo(target.getX(), target.getY(), target.getZ());
        bolt.setVisualOnly(false);
        level.addFreshEntity(bolt);

        // Add some extra direct damage scaling with upgrades (vanilla lightning is ~5 dmg).
        float extra = Math.max(0.0F, damage - 6.0F);
        if (extra > 0.0F) {
            target.hurt(level.damageSources().lightningBolt(), extra);
        }

        level.playSound(null, pos, SoundEvents.TRIDENT_THUNDER, SoundSource.BLOCKS, 1.0F, 1.0F);
    }

    private void fireFrost(Level level, BlockPos pos, Vec3 dir, float damage) {
        FrostShardEntity shard = new FrostShardEntity(ModEntities.FROST_SHARD.get(), level);
        Vec3 muzzle = muzzlePos(level, pos, dir, 1.02, 1.08);
        shard.setPos(muzzle.x, muzzle.y, muzzle.z);
        shard.shoot(dir.x, dir.y, dir.z, 1.8F, 1.0F);
        shard.setDamage(damage);

        // slow duration scales with upgrades
        int slowTicks = (2 + (upgradeLevel - 1)) * 20;
        shard.setSlowTicks(slowTicks);

        level.addFreshEntity(shard);
        level.playSound(null, pos, SoundEvents.SNOWBALL_THROW, SoundSource.BLOCKS, 0.8F, 1.2F);
    }

    private void fireGatling(Level level, BlockPos pos, Vec3 dir, float damage) {
        IronBulletEntity bullet = new IronBulletEntity(ModEntities.IRON_BULLET_PROJECTILE.get(), level);
        Vec3 muzzle = muzzlePos(level, pos, dir, 1.02, 1.10);
        bullet.setPos(muzzle.x, muzzle.y, muzzle.z);
        bullet.shoot(dir.x, dir.y, dir.z, 3.0F, 2.0F);
        bullet.setDamage(damage);

        level.addFreshEntity(bullet);
        level.playSound(null, pos, SoundEvents.CROSSBOW_SHOOT, SoundSource.BLOCKS, 0.7F, 1.35F);
    }

    private void fireCannon(Level level, BlockPos pos, Vec3 dir, float damage) {
        CannonballEntity ball = new CannonballEntity(ModEntities.CANNONBALL.get(), level);
        Vec3 muzzle = muzzlePos(level, pos, dir, 1.05, 1.20);
        ball.setPos(muzzle.x, muzzle.y, muzzle.z);
        ball.shoot(dir.x, dir.y, dir.z, 1.5F, 0.6F);

        // Explosion power scales gently.
        float base = 2.2F;
        float power = Mth.clamp(base * TurretUpgrades.damageMultiplier(upgradeLevel), base, 4.0F);
        ball.setExplosionPower(power);

        level.addFreshEntity(ball);
        level.playSound(null, pos, SoundEvents.GENERIC_EXPLODE, SoundSource.BLOCKS, 0.7F, 1.2F);
    }

    // ----------------------------
    // Menu provider
    // ----------------------------

    @Override
    public Component getDisplayName() {
        return Component.translatable("block.turretcraft." + kind().name().toLowerCase() + "_turret");
    }

    @Nullable
    @Override
    public net.minecraft.world.inventory.AbstractContainerMenu createMenu(int id, net.minecraft.world.entity.player.Inventory inv, Player player) {
        return new com.cz.turretcraft.menu.TurretMenu(id, inv, this);
    }

    // ----------------------------
    // Networking / NBT
    // ----------------------------

    @Override
    public void saveAdditional(CompoundTag tag) {
        super.saveAdditional(tag);
        tag.putInt("Ammo", ammo);
        if (!ammoTemplate.isEmpty()) tag.put("AmmoTemplate", ammoTemplate.save(new CompoundTag()));
        tag.putBoolean("TargetPlayers", targetPlayers);
        if (owner != null) tag.putUUID("Owner", owner);
        if (teamName != null) tag.putString("TeamName", teamName);
        tag.putInt("UpgradeLevel", upgradeLevel);
        tag.put("Inventory", itemHandler.serializeNBT());
    }

    @Override
    public void load(CompoundTag tag) {
        super.load(tag);
        ammo = tag.getInt("Ammo");
        ammoTemplate = tag.contains("AmmoTemplate") ? ItemStack.of(tag.getCompound("AmmoTemplate")) : ItemStack.EMPTY;
        targetPlayers = tag.getBoolean("TargetPlayers");
        if (tag.hasUUID("Owner")) owner = tag.getUUID("Owner"); else owner = null;
        if (tag.contains("TeamName")) teamName = tag.getString("TeamName"); else teamName = null;
        upgradeLevel = TurretUpgrades.clampLevel(tag.getInt("UpgradeLevel"));
        if (tag.contains("Inventory")) itemHandler.deserializeNBT(tag.getCompound("Inventory"));

        // Clamp ammo to current max
        ammo = Mth.clamp(ammo, 0, getMaxAmmo());
    }

    @Override
    public CompoundTag getUpdateTag() {
        return saveWithoutMetadata();
    }

    @Nullable
    @Override
    public ClientboundBlockEntityDataPacket getUpdatePacket() {
        return ClientboundBlockEntityDataPacket.create(this);
    }

    @Override
    public void onDataPacket(Connection net, ClientboundBlockEntityDataPacket pkt) {
        CompoundTag tag = pkt.getTag();
        if (tag != null) load(tag);
    }

    @Override
    public void setRemoved() {
        super.setRemoved();
        lazyItemHandler.invalidate();
    }

    public LazyOptional<ItemStackHandler> getItemHandler() {
        return lazyItemHandler;
    }

    // ----------------------------
    // Upgrade utility for Menu
    // ----------------------------

    public boolean canUpgrade() {
        return upgradeLevel < TurretUpgrades.MAX_LEVEL;
    }

    public void applyUpgradeSuccess(Level level, BlockPos pos, Player player, int newLevel) {
        int old = this.upgradeLevel;
        this.upgradeLevel = TurretUpgrades.clampLevel(newLevel);
        this.ammo = Mth.clamp(this.ammo, 0, getMaxAmmo());
        setChanged();

        // Sound feedback
        level.playSound(null, pos, SoundEvents.PLAYER_LEVELUP, SoundSource.BLOCKS, 0.9F, 1.25F);
        level.playSound(null, pos, SoundEvents.ANVIL_USE, SoundSource.BLOCKS, 0.6F, 1.6F);

        player.displayClientMessage(Component.translatable("msg.turretcraft.upgrade.success", old, this.upgradeLevel), false);
    }
}
