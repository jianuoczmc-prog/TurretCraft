package com.cz.turretcraft.client.widget;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.AbstractButton;
import net.minecraft.client.gui.narration.NarratedElementType;
import net.minecraft.client.gui.narration.NarrationElementOutput;
import net.minecraft.network.chat.Component;
import net.minecraft.util.Mth;

/**
 * A simple custom button that auto-scales its label so the full text is always visible.
 *
 * This avoids text overlap across different languages and GUI scales.
 */
public class FittedTextButton extends AbstractButton {
    private final Runnable onPress;

    public FittedTextButton(int x, int y, int width, int height, Component message, Runnable onPress) {
        super(x, y, width, height, message);
        this.onPress = onPress;
    }

    @Override
    public void onPress() {
        if (this.active && this.onPress != null) {
            this.onPress.run();
        }
    }

    @Override
    protected void renderWidget(GuiGraphics graphics, int mouseX, int mouseY, float partialTicks) {
        if (!this.visible) return;

        Minecraft mc = Minecraft.getInstance();
        if (mc == null) return;

        boolean hovered = mouseX >= this.getX() && mouseX < this.getX() + this.width
                && mouseY >= this.getY() && mouseY < this.getY() + this.height;

        // Minimal panel style (keeps TurretCraft's clean look and works at any UI scale)
        int x = this.getX();
        int y = this.getY();

        int bg;
        int border;
        if (!this.active) {
            bg = 0x80202020;
            border = 0xA0101010;
        } else if (hovered) {
            bg = 0xA02F2F2F;
            border = 0xA01A1A1A;
        } else {
            bg = 0x90303030;
            border = 0xA01A1A1A;
        }

        graphics.fill(x, y, x + this.width, y + this.height, bg);
        graphics.fill(x, y, x + this.width, y + 1, border);
        graphics.fill(x, y + this.height - 1, x + this.width, y + this.height, border);
        graphics.fill(x, y, x + 1, y + this.height, border);
        graphics.fill(x + this.width - 1, y, x + this.width, y + this.height, border);

        // Text (auto scale to fit)
        Component msg = this.getMessage();
        String s = msg == null ? "" : msg.getString();
        int textW = mc.font.width(s);
        int innerW = Math.max(1, this.width - 8);
        float scale = 1.0f;
        if (textW > innerW) {
            scale = Mth.clamp(innerW / (float) textW, 0.35f, 1.0f);
        }

        int color = this.active ? 0xE0E0E0 : 0xA0A0A0;
        float textH = 9.0f * scale;
        int ty = y + Mth.floor((this.height - textH) / 2.0f);
        int cx = x + (this.width / 2);

        graphics.pose().pushPose();
        graphics.pose().translate(cx, ty, 0);
        graphics.pose().scale(scale, scale, 1.0f);
        graphics.drawString(mc.font, s, -textW / 2, 0, color, false);
        graphics.pose().popPose();
    }

    @Override
    protected void updateWidgetNarration(NarrationElementOutput out) {
        out.add(NarratedElementType.TITLE, this.getMessage());
    }
}
