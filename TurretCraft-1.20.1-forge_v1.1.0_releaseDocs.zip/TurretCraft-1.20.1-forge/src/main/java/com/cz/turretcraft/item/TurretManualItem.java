package com.cz.turretcraft.item;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.StringTag;
import net.minecraft.nbt.Tag;
import net.minecraft.network.chat.Component;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.WrittenBookItem;
import net.minecraft.world.level.Level;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;

/**
 * In-game manual item (acts like a written book) with translatable pages.
 *
 * We generate the pages' NBT on first use, and mark it as "resolved" so the
 * server won't rewrite components (we want the client to localize).
 */
public class TurretManualItem extends WrittenBookItem {

    private static final String TAG_INIT = "turretcraft_manual_init";
    private static final String TAG_VER = "turretcraft_manual_ver";
    // Bump this whenever manual pages or GUI mapping changes so old books auto-refresh.
    private static final int MANUAL_VERSION = 4;
    private static final int PAGE_COUNT = 14;

    /**
     * Vanilla validates written books and requires non-empty author/title.
     * The user requested an "empty" author display, so we use an invisible
     * character that is NOT whitespace (so it won't be stripped to empty).
     */
    private static final String BLANK_AUTHOR = "\u2063"; // invisible separator

    public TurretManualItem(Properties props) {
        super(props);
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        // Client: generate pages + localize title, then open a vanilla BookViewScreen immediately.
        // (Do NOT rely on ClientboundOpenBookPacket, because the client only opens the GUI for
        // Items.WRITTEN_BOOK / Items.WRITABLE_BOOK, not for custom WrittenBookItem subclasses.)
        if (level.isClientSide) {
            ensureBookTag(stack);
            DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> {
                com.cz.turretcraft.client.ManualClientHelper.localizeBookTitle(stack);
                com.cz.turretcraft.client.ManualClientHelper.openManual(stack);
            });
            return InteractionResultHolder.sidedSuccess(stack, true);
        }

        // Server: still ensure NBT exists (so inventories remain consistent), but do not send open-book packets.
        ensureBookTag(stack);
        return InteractionResultHolder.sidedSuccess(stack, false);
    }

    private static void ensureBookTag(ItemStack stack) {
        CompoundTag tag = stack.getOrCreateTag();
        boolean inited = tag.getBoolean(TAG_INIT);

        // DO NOT setHoverName() here: that would turn the item name italic and make it
        // look like the book "changed" after right-click. The display name is already
        // localized via lang files.

        // If the book was initialized by an older version, fix its title/author and missing pages.
        // (Book title is NOT translatable, so use a neutral fixed string.)
        String oldTitle = tag.getString("title");
        if (oldTitle.isEmpty()) {
            tag.putString("title", "TurretCraft");
        }
        // Author: "blank" but still valid.
        tag.putString("author", BLANK_AUTHOR);
        tag.putString("filtered_author", BLANK_AUTHOR);

        int ver = tag.getInt(TAG_VER);
        if (inited && ver == MANUAL_VERSION && tag.contains("pages", Tag.TAG_LIST)) {
            return;
        }

        // NOTE: Written book title is a plain string (not translatable). Keep it neutral so it won't
        // "turn English" on Chinese clients after first use.
        // Title will be localized on the client right before opening.
        // Keep a neutral default here so servers don't force English into the NBT.
        tag.putString("title", "TurretCraft");
        tag.putString("filtered_title", "TurretCraft");
        tag.putString("author", BLANK_AUTHOR);
        tag.putString("filtered_author", BLANK_AUTHOR);

        ListTag pages = new ListTag();
        // Each page is a JSON text component, using translate keys for localization.
        // Keep page count in sync with lang keys: book.turretcraft.manual.p1 ... p14
        for (int i = 1; i <= PAGE_COUNT; i++) {
            pages.add(StringTag.valueOf(Component.Serializer.toJson(Component.translatable("book.turretcraft.manual.p" + i))));
        }
        tag.put("pages", pages);

        // Keep components translatable; do not force "resolved".

        tag.putInt(TAG_VER, MANUAL_VERSION);
        tag.putBoolean(TAG_INIT, true);
    }
}
