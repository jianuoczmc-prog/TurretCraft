package com.cz.turretcraft.registry;

import com.cz.turretcraft.TurretCraft;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.RegistryObject;

public class ModCreativeTabs {
    public static final DeferredRegister<CreativeModeTab> TABS = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, TurretCraft.MODID);

    public static final RegistryObject<CreativeModeTab> TURRETCRAFT_TAB = TABS.register("turretcraft", () -> CreativeModeTab.builder()
            .title(Component.translatable("creativetab.turretcraft"))
            .icon(() -> new ItemStack(ModItems.ARROW_TURRET.get()))
            .displayItems((params, output) -> {
                output.accept(ModItems.ARROW_TURRET.get());
                output.accept(ModItems.FIRE_TURRET.get());
                output.accept(ModItems.LIGHTNING_TURRET.get());
                output.accept(ModItems.FROST_TURRET.get());
                output.accept(ModItems.GATLING_TURRET.get());
                output.accept(ModItems.POISON_TURRET.get());
                output.accept(ModItems.CANNON_TURRET.get());

                output.accept(ModItems.FROST_SHARD.get());
                output.accept(ModItems.IRON_BULLET.get());
                output.accept(ModItems.POISON_DART.get());
                output.accept(ModItems.CANNONBALL.get());

                output.accept(ModItems.TURRET_FIRMWARE.get());
                output.accept(ModItems.TURRET_MANUAL.get());
            })
            .build());
}
