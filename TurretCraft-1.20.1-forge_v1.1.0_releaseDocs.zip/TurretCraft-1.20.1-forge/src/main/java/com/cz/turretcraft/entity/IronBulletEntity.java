package com.cz.turretcraft.entity;

import com.cz.turretcraft.registry.ModItems;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.projectile.ThrowableItemProjectile;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.EntityHitResult;

/**
 * Fast, low-gravity projectile used by the Gatling turret.
 * Implemented as a ThrowableItemProjectile so it can be rendered by ThrownItemRenderer.
 */
public class IronBulletEntity extends ThrowableItemProjectile {
    private static final EntityDataAccessor<Float> DAMAGE = SynchedEntityData.defineId(IronBulletEntity.class, EntityDataSerializers.FLOAT);

    public IronBulletEntity(EntityType<? extends IronBulletEntity> type, Level level) {
        super(type, level);
    }

    @Override
    protected void defineSynchedData() {
        super.defineSynchedData();
        this.entityData.define(DAMAGE, 2.0F);
    }

    public void setDamage(float dmg) {
        this.entityData.set(DAMAGE, dmg);
    }

    public float getDamage() {
        return this.entityData.get(DAMAGE);
    }

    @Override
    protected Item getDefaultItem() {
        return ModItems.IRON_BULLET.get();
    }

    @Override
    protected float getGravity() {
        return 0.01F;
    }

    @Override
    public void tick() {
        super.tick();

        if (this.level().isClientSide) {
            // light trail
            this.level().addParticle(ParticleTypes.SMOKE, this.getX(), this.getY(), this.getZ(), 0.0, 0.0, 0.0);
        }

        if (this.tickCount > 80) {
            this.discard();
        }
    }

    @Override
    protected void onHitEntity(EntityHitResult hit) {
        super.onHitEntity(hit);

        Entity target = hit.getEntity();
        DamageSource src = this.damageSources().thrown(this, this.getOwner());
        target.hurt(src, getDamage());

        this.discard();
    }

    @Override
    protected void onHitBlock(BlockHitResult hit) {
        super.onHitBlock(hit);
        this.discard();
    }


@Override
public net.minecraft.network.protocol.Packet<net.minecraft.network.protocol.game.ClientGamePacketListener> getAddEntityPacket() {
    return net.minecraftforge.network.NetworkHooks.getEntitySpawningPacket(this);
}
}
