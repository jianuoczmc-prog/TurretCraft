package com.cz.turretcraft.registry;

import com.cz.turretcraft.TurretCraft;
import com.cz.turretcraft.entity.CannonballEntity;
import com.cz.turretcraft.entity.FrostShardEntity;
import com.cz.turretcraft.entity.IronBulletEntity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModEntities {
    public static final DeferredRegister<EntityType<?>> ENTITY_TYPES = DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, TurretCraft.MODID);

    public static final RegistryObject<EntityType<FrostShardEntity>> FROST_SHARD = ENTITY_TYPES.register(
            "frost_shard",
            () -> EntityType.Builder.<FrostShardEntity>of(FrostShardEntity::new, MobCategory.MISC)
                    .sized(0.25F, 0.25F)
                    .clientTrackingRange(4)
                    .updateInterval(10)
                    .build("frost_shard")
    );

        public static final RegistryObject<EntityType<IronBulletEntity>> IRON_BULLET_PROJECTILE = ENTITY_TYPES.register(
            "iron_bullet_projectile",
            () -> EntityType.Builder.<IronBulletEntity>of(IronBulletEntity::new, MobCategory.MISC)
                    .sized(0.2F, 0.2F)
                    .clientTrackingRange(4)
                    .updateInterval(10)
                    .build("iron_bullet_projectile")
    );

    public static final RegistryObject<EntityType<CannonballEntity>> CANNONBALL = ENTITY_TYPES.register(
            "cannonball",
            () -> EntityType.Builder.<CannonballEntity>of(CannonballEntity::new, MobCategory.MISC)
                    .sized(0.3F, 0.3F)
                    .clientTrackingRange(4)
                    .updateInterval(10)
                    .build("cannonball")
    );
}
