package com.cz.turretcraft.client.render;

import com.cz.turretcraft.entity.IronBulletEntity;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.ThrownItemRenderer;

/**
 * Renders the iron bullet as an item sprite, but rotated sideways so it looks like a
 * horizontal bullet when fired.
 */
public class IronBulletRenderer extends ThrownItemRenderer<IronBulletEntity> {
    public IronBulletRenderer(EntityRendererProvider.Context ctx) {
        super(ctx);
    }

    @Override
    public void render(IronBulletEntity entity, float entityYaw, float partialTicks, PoseStack poseStack,
                       MultiBufferSource buffer, int packedLight) {
        poseStack.pushPose();
        // Rotate the sprite 90deg so it doesn't look like a vertical "standing" item.
        poseStack.mulPose(Axis.ZP.rotationDegrees(90.0F));
        super.render(entity, entityYaw, partialTicks, poseStack, buffer, packedLight);
        poseStack.popPose();
    }
}
