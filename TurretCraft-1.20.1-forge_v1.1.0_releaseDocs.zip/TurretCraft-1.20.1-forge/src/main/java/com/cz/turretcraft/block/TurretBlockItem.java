package com.cz.turretcraft.block;

import net.minecraft.network.chat.Component;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;

import org.jetbrains.annotations.Nullable;

import java.util.List;

public class TurretBlockItem extends BlockItem {
    public TurretBlockItem(net.minecraft.world.level.block.Block block, Properties properties) {
        super(block, properties);
    }

    private @Nullable TurretKind kind() {
        if (getBlock() instanceof TurretBlock tb) {
            return tb.getKind();
        }
        return null;
    }

    @Override
    public void appendHoverText(ItemStack stack, @Nullable Level level, List<Component> tooltip, TooltipFlag flag) {
        TurretKind kind = kind();
        if (kind != null) {
            tooltip.add(Component.translatable("tooltip.turretcraft.ammo", Component.translatable(kind.ammoItem().getDescriptionId())));
            tooltip.add(Component.translatable("tooltip.turretcraft.range", String.valueOf(kind.range())));
            tooltip.add(Component.translatable("tooltip.turretcraft.cooldown", String.valueOf(kind.cooldownTicks())));
            tooltip.add(Component.translatable("tooltip.turretcraft.damage", String.valueOf(kind.damage())));
        }
        super.appendHoverText(stack, level, tooltip, flag);
    }
}
