package com.cz.turretcraft.entity;

import com.cz.turretcraft.registry.ModItems;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.projectile.ThrowableItemProjectile;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.EntityHitResult;

/**
 * Frost shard projectile that slows targets on hit.
 */
public class FrostShardEntity extends ThrowableItemProjectile {

    private static final EntityDataAccessor<Integer> SLOW_TICKS = SynchedEntityData.defineId(FrostShardEntity.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Float> DAMAGE = SynchedEntityData.defineId(FrostShardEntity.class, EntityDataSerializers.FLOAT);

    public FrostShardEntity(EntityType<? extends FrostShardEntity> type, Level level) {
        super(type, level);
    }

    @Override
    protected void defineSynchedData() {
        super.defineSynchedData();
        this.entityData.define(SLOW_TICKS, 60);
        this.entityData.define(DAMAGE, 2.0F);
    }

    @Override
    protected Item getDefaultItem() {
        return ModItems.FROST_SHARD.get();
    }

    @Override
    protected float getGravity() {
        return 0.03F;
    }

    public void setSlowTicks(int ticks) {
        this.entityData.set(SLOW_TICKS, ticks);
    }

    public int getSlowTicks() {
        return this.entityData.get(SLOW_TICKS);
    }

    public void setDamage(float dmg) {
        this.entityData.set(DAMAGE, dmg);
    }

    public float getDamage() {
        return this.entityData.get(DAMAGE);
    }

    @Override
    public void tick() {
        super.tick();
        if (this.level().isClientSide) {
            this.level().addParticle(ParticleTypes.SNOWFLAKE, this.getX(), this.getY(), this.getZ(), 0.0, 0.0, 0.0);
        }
        if (this.tickCount > 80) this.discard();
    }

    @Override
    protected void onHitEntity(EntityHitResult hit) {
        super.onHitEntity(hit);

        Entity e = hit.getEntity();
        if (!this.level().isClientSide && e instanceof LivingEntity le) {
            le.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, getSlowTicks(), 1));
            le.hurt(this.damageSources().thrown(this, this.getOwner()), getDamage());
        }

        this.discard();
    }

    @Override
    protected void onHitBlock(BlockHitResult hit) {
        super.onHitBlock(hit);
        this.discard();
    }


@Override
public net.minecraft.network.protocol.Packet<net.minecraft.network.protocol.game.ClientGamePacketListener> getAddEntityPacket() {
    return net.minecraftforge.network.NetworkHooks.getEntitySpawningPacket(this);
}
}
