package com.cz.turretcraft.client.render;

import com.cz.turretcraft.TurretCraft;
import com.cz.turretcraft.block.TurretKind;
import com.cz.turretcraft.blockentity.TurretBlockEntity;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.math.Axis;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.block.BlockRenderDispatcher;
import net.minecraft.client.renderer.blockentity.BlockEntityRenderer;
import net.minecraft.client.renderer.blockentity.BlockEntityRendererProvider;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.client.resources.model.BakedModel;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.level.block.state.BlockState;

/**
 * Renders a rotating turret head + pitching barrel on top of the static base model.
 */
public class TurretBlockEntityRenderer implements BlockEntityRenderer<TurretBlockEntity> {

    public TurretBlockEntityRenderer(BlockEntityRendererProvider.Context ctx) {
    }

    private static String key(TurretKind kind) {
        return switch (kind) {
            case ARROW -> "arrow";
            case FIRE -> "fire";
            case LIGHTNING -> "lightning";
            case FROST -> "frost";
            case GATLING -> "gatling";
            case POISON -> "poison";
            case CANNON -> "cannon";
        };
    }

    private static ResourceLocation modelLoc(String key, String part) {
        // part: head / barrel
        return new ResourceLocation(TurretCraft.MODID, "block/" + key + "_turret_" + part);
    }

    @Override
    public void render(TurretBlockEntity turret, float partialTick, PoseStack poseStack, MultiBufferSource buffer, int packedLight, int packedOverlay) {
        BlockState state = turret.getBlockState();
        TurretKind kind = turret.getKind();
        String k = key(kind);

        Minecraft mc = Minecraft.getInstance();
        BlockRenderDispatcher brd = mc.getBlockRenderer();

        BakedModel headModel = mc.getModelManager().getModel(modelLoc(k, "head"));
        BakedModel barrelModel = mc.getModelManager().getModel(modelLoc(k, "barrel"));

        float yaw = turret.renderYaw(partialTick);
        float pitch = turret.renderPitch(partialTick);
        float recoil = turret.renderRecoil(partialTick);

        // Use solid layer for these simple block-texture models.
        VertexConsumer vc = buffer.getBuffer(RenderType.solid());

        // --- Render head (yaw) ---
        poseStack.pushPose();
        poseStack.translate(0.5D, 0.0D, 0.5D);
        poseStack.mulPose(Axis.YP.rotationDegrees(yaw));
        poseStack.translate(-0.5D, 0.0D, -0.5D);
        brd.getModelRenderer().renderModel(poseStack.last(), vc, state, headModel, 1.0F, 1.0F, 1.0F, packedLight, OverlayTexture.NO_OVERLAY);
        poseStack.popPose();

        // --- Render barrel (yaw + pitch + recoil) ---
        poseStack.pushPose();
        poseStack.translate(0.5D, 0.0D, 0.5D);
        poseStack.mulPose(Axis.YP.rotationDegrees(yaw));
        poseStack.translate(-0.5D, 0.0D, -0.5D);

        // Pivot near barrel base: (8, 8, 12) in model pixels
        poseStack.translate(0.5D, 0.5D, 0.75D);
        poseStack.mulPose(Axis.XP.rotationDegrees(pitch));
        // Recoil along local forward axis (pull back = -Z)
        poseStack.translate(0.0D, 0.0D, -recoil);
        poseStack.translate(-0.5D, -0.5D, -0.75D);

        brd.getModelRenderer().renderModel(poseStack.last(), vc, state, barrelModel, 1.0F, 1.0F, 1.0F, packedLight, OverlayTexture.NO_OVERLAY);
        poseStack.popPose();
    }

    @Override
    public boolean shouldRenderOffScreen(TurretBlockEntity pBlockEntity) {
        return true;
    }
}
