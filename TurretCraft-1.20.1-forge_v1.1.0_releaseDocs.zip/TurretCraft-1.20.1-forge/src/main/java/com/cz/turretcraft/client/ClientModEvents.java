package com.cz.turretcraft.client;

import com.cz.turretcraft.TurretCraft;
import com.cz.turretcraft.client.render.IronBulletRenderer;
import com.cz.turretcraft.client.render.TurretBlockEntityRenderer;
import com.cz.turretcraft.client.screen.TurretScreen;
import com.cz.turretcraft.registry.ModBlockEntities;
import com.cz.turretcraft.registry.ModEntities;
import com.cz.turretcraft.registry.ModMenus;
import net.minecraft.client.gui.screens.MenuScreens;
import net.minecraft.client.renderer.blockentity.BlockEntityRenderers;
import net.minecraft.client.renderer.entity.EntityRenderers;
import net.minecraft.client.renderer.entity.ThrownItemRenderer;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.ModelEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.event.lifecycle.FMLClientSetupEvent;

@Mod.EventBusSubscriber(modid = TurretCraft.MODID, bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class ClientModEvents {
    @SubscribeEvent
    public static void onClientSetup(FMLClientSetupEvent event) {
        event.enqueueWork(() -> {
            EntityRenderers.register(ModEntities.FROST_SHARD.get(), ThrownItemRenderer::new);
            EntityRenderers.register(ModEntities.CANNONBALL.get(), ThrownItemRenderer::new);
            EntityRenderers.register(ModEntities.IRON_BULLET_PROJECTILE.get(), IronBulletRenderer::new);

            MenuScreens.register(ModMenus.TURRET_MENU.get(), TurretScreen::new);

            // Turret head/barrel animation renderer
            BlockEntityRenderers.register(ModBlockEntities.TURRET.get(), TurretBlockEntityRenderer::new);
        });
    }

    /**
     * Ensure our head/barrel models are baked even though blockstates only reference the base model.
     */
    @SubscribeEvent
    public static void onRegisterAdditionalModels(ModelEvent.RegisterAdditional event) {
        for (String k : new String[]{"arrow", "fire", "lightning", "frost", "gatling", "poison", "cannon"}) {
            event.register(new ResourceLocation(TurretCraft.MODID, "block/" + k + "_turret_head"));
            event.register(new ResourceLocation(TurretCraft.MODID, "block/" + k + "_turret_barrel"));
        }
        // Shared parts
        event.register(new ResourceLocation(TurretCraft.MODID, "block/turret_head_part"));
        event.register(new ResourceLocation(TurretCraft.MODID, "block/turret_barrel_part"));
    }
}
