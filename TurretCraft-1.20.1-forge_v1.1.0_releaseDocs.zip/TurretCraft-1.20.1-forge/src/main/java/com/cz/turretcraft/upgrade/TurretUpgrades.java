package com.cz.turretcraft.upgrade;

import com.cz.turretcraft.registry.ModItems;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;

import java.util.ArrayList;
import java.util.List;

/**
 * Turret upgrade rules (Level 1 -> 5).
 *
 * Upgrade slot mapping (GUI):
 * 0 Iron Ingot
 * 1 Redstone
 * 2 Gold Ingot
 * 3 Diamond
 * 4 Netherite Scrap
 * 5 Turret Firmware
 */
public final class TurretUpgrades {
    private TurretUpgrades() {}

    public static final int MAX_LEVEL = 5;

    /** Simple requirement record. */
    public record Requirement(Item item, int count) {}

    public static int clampLevel(int level) {
        if (level < 1) return 1;
        return Math.min(MAX_LEVEL, level);
    }

    // -----------------------
    // Stat scaling
    // -----------------------
    public static int maxAmmo(int level) {
        int l = clampLevel(level);
        return 256 + (l - 1) * 64;
    }

    public static int rangeBonus(int level) {
        int l = clampLevel(level);
        return (l - 1) * 2;
    }

    public static float damageMultiplier(int level) {
        int l = clampLevel(level);
        // Stronger growth curve (requested): damage feels noticeably better each upgrade.
        return switch (l) {
            case 1 -> 1.00F;
            case 2 -> 1.35F;
            case 3 -> 1.80F;
            case 4 -> 2.35F;
            case 5 -> 3.00F;
            default -> 1.00F;
        };
    }

    public static float cooldownMultiplier(int level) {
        int l = clampLevel(level);
        float m = 1.0F - (l - 1) * 0.10F;
        return Math.max(0.60F, m);
    }

    public static float ammoSaveChance(int level) {
        int l = clampLevel(level);
        return (l - 1) * 0.05F; // 0%, 5%, 10%, 15%, 20%
    }

    // -----------------------
    // Materials
    // -----------------------
    public static Item slotItem(int slot) {
        return switch (slot) {
            case 0 -> Items.IRON_INGOT;
            case 1 -> Items.REDSTONE;
            case 2 -> Items.GOLD_INGOT;
            case 3 -> Items.DIAMOND;
            case 4 -> Items.NETHERITE_SCRAP;
            case 5 -> ModItems.TURRET_FIRMWARE.get();
            default -> Items.AIR;
        };
    }

    public static int slotForItem(ItemStack stack) {
        Item it = stack.getItem();
        if (it == Items.IRON_INGOT) return 0;
        if (it == Items.REDSTONE) return 1;
        if (it == Items.GOLD_INGOT) return 2;
        if (it == Items.DIAMOND) return 3;
        if (it == Items.NETHERITE_SCRAP) return 4;
        if (it == ModItems.TURRET_FIRMWARE.get()) return 5;
        return -1;
    }

    /**
     * Requirements to upgrade FROM current level -> next level.
     * If current level >= MAX_LEVEL, returns empty list.
     */
    public static List<Requirement> requirementsForNextLevel(int currentLevel) {
        int level = clampLevel(currentLevel);
        if (level >= MAX_LEVEL) return List.of();

        List<Requirement> req = new ArrayList<>();
        switch (level) {
            case 1 -> {
                // Lv1 -> Lv2 (smooth curve): only iron + firmware
                req.add(new Requirement(Items.IRON_INGOT, 4));
                req.add(new Requirement(ModItems.TURRET_FIRMWARE.get(), 1));
            }
            case 2 -> {
                // Lv2 -> Lv3: add redstone
                req.add(new Requirement(Items.IRON_INGOT, 8));
                req.add(new Requirement(Items.REDSTONE, 16));
                req.add(new Requirement(ModItems.TURRET_FIRMWARE.get(), 1));
            }
            case 3 -> {
                // Lv3 -> Lv4: add gold
                req.add(new Requirement(Items.IRON_INGOT, 12));
                req.add(new Requirement(Items.REDSTONE, 24));
                req.add(new Requirement(Items.GOLD_INGOT, 12));
                req.add(new Requirement(ModItems.TURRET_FIRMWARE.get(), 2));
            }
            case 4 -> {
                // Lv4 -> Lv5: full set
                req.add(new Requirement(Items.IRON_INGOT, 16));
                req.add(new Requirement(Items.REDSTONE, 32));
                req.add(new Requirement(Items.GOLD_INGOT, 16));
                req.add(new Requirement(Items.DIAMOND, 4));
                req.add(new Requirement(Items.NETHERITE_SCRAP, 2));
                req.add(new Requirement(ModItems.TURRET_FIRMWARE.get(), 2));
            }
            default -> {}
        }
        return req;
    }
}
