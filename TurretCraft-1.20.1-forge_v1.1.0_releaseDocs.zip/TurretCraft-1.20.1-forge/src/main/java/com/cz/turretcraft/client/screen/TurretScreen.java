package com.cz.turretcraft.client.screen;

import com.cz.turretcraft.client.widget.FittedTextButton;
import com.cz.turretcraft.menu.TurretMenu;
import com.cz.turretcraft.upgrade.TurretUpgrades;
import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.Util;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.AbstractButton;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.FormattedCharSequence;
import net.minecraft.util.Mth;
import net.minecraft.world.Container;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.item.Item;

import java.util.ArrayList;
import java.util.List;

/**
 * Turret GUI (Scheme 2 / v4 layout).
 *
 * Notes:
 * - We draw progress bars (ammo / cooldown) directly on the v4 texture.
 * - The upgrade button is icon-style (custom rune-chip icon) to avoid looking like other mods.
 * - All dynamic values are read from TurretMenu's synced ContainerData so the GUI updates immediately.
 */
public class TurretScreen extends AbstractContainerScreen<TurretMenu> {
    private static final ResourceLocation GUI_TEXTURE = new ResourceLocation("turretcraft", "textures/gui/turret_gui_v4.png");
    private static final ResourceLocation ICONS = new ResourceLocation("turretcraft", "textures/gui/tc_icons.png");

    // v4 texture metrics
    private static final int TEX_W = 176;
    private static final int TEX_H = 202;

    // Progress bar frames on v4 texture
    private static final int BAR_AMMO_X = 8;
    // NOTE: User requested moving "Monster/Unload/Ammo/CD" down, but the 2x3 material grid must not move.
    // So we keep the bar *frames* at their original Y, and only move the bar texts down a bit.
    private static final int BAR_AMMO_Y = 50;
    private static final int BAR_CD_X = 90;
    private static final int BAR_CD_Y = 50;

    // Controls offset (Monster / Unload).
    // Keep it 0 and place buttons above the bars so nothing overlaps (especially in English).
    private static final int CONTROL_OFFSET_Y = 0;
    private static final int BAR_W = 78;
    private static final int BAR_H = 17;
    private static final int BAR_INNER_W = BAR_W - 2;
    private static final int BAR_INNER_H = BAR_H - 2;

    // Upgrade slots (match TurretMenu positions)
    private static final int SLOT_IRON_X = 90, SLOT_IRON_Y = 70;
    private static final int SLOT_FW_X = 108, SLOT_FW_Y = 70;
    private static final int SLOT_RED_X = 126, SLOT_RED_Y = 70;
    private static final int SLOT_GOLD_X = 90, SLOT_GOLD_Y = 88;
    private static final int SLOT_DIAMOND_X = 108, SLOT_DIAMOND_Y = 88;
    private static final int SLOT_NETHER_X = 126, SLOT_NETHER_Y = 88;

    private FittedTextButton toggleTargetButton;
    private FittedTextButton unloadButton;
    private AbstractButton upgradeButton;

    public TurretScreen(TurretMenu menu, Inventory inv, Component title) {
        super(menu, inv, title);
        this.imageWidth = TEX_W;
        this.imageHeight = TEX_H;
    }

    @Override
    protected void init() {
        super.init();

        int x = this.leftPos;
        int y = this.topPos;

        // Two main text buttons (placed ABOVE the bars)
        this.toggleTargetButton = new FittedTextButton(
                x + 8, y + 30 + CONTROL_OFFSET_Y,
                78, 18,
                getToggleText(),
                () -> this.minecraft.gameMode.handleInventoryButtonClick(this.menu.containerId, 0)
        );

        this.unloadButton = new FittedTextButton(
                x + 90, y + 30 + CONTROL_OFFSET_Y,
                78, 18,
                Component.translatable("button.turretcraft.unload_ammo"),
                () -> this.minecraft.gameMode.handleInventoryButtonClick(this.menu.containerId, 1)
        );

        // Icon-style upgrade button (right of 2x3 material grid)
        // Uses a custom widget so it doesn't look like vanilla buttons from other mods.
        this.upgradeButton = new UpgradeIconButton(x + 148, y + 95);

        addRenderableWidget(toggleTargetButton);
        addRenderableWidget(unloadButton);
        addRenderableWidget(upgradeButton);
    }

    private Component getToggleText() {
        return this.menu.isTargetPlayers()
                ? Component.translatable("button.turretcraft.target_players")
                : Component.translatable("button.turretcraft.target_monsters");
    }

    @Override
    public void containerTick() {
        super.containerTick();
        if (toggleTargetButton != null) toggleTargetButton.setMessage(getToggleText());
        if (upgradeButton != null) {
            int lvl = menu.getUpgradeLevel();
            upgradeButton.active = lvl < TurretUpgrades.MAX_LEVEL;
        }
    }

    @Override
    protected void renderBg(GuiGraphics graphics, float partialTicks, int mouseX, int mouseY) {
        RenderSystem.setShaderColor(1F, 1F, 1F, 1F);
        // v4 texture is exactly 176x202 (NOT 256x256).
        graphics.blit(GUI_TEXTURE, this.leftPos, this.topPos, 0, 0, this.imageWidth, this.imageHeight, TEX_W, TEX_H);

        // Bars
        drawAmmoBar(graphics);
        drawCooldownBar(graphics);
    }
 
    private void drawAmmoBar(GuiGraphics graphics) {
        int ammo = menu.getAmmo();
        int max = Math.max(1, menu.getMaxAmmo());
        float ratio = Mth.clamp(ammo / (float) max, 0F, 1F);
        int fill = Math.round(ratio * BAR_INNER_W);

        int x0 = this.leftPos + BAR_AMMO_X + 1;
        int y0 = this.topPos + BAR_AMMO_Y + 1;
        // Semi-transparent fill so it looks good on different UI scales.
        graphics.fill(x0, y0, x0 + fill, y0 + BAR_INNER_H, 0xAA2FB5B3);

        // Center text (auto-scale to bar width so it's always fully visible)
        String s = ammo + "/" + max;
        drawCenteredScaledText(graphics, s,
                this.leftPos + BAR_AMMO_X + (BAR_W / 2),
                this.topPos + BAR_AMMO_Y,
                BAR_INNER_W,
                BAR_H,
                0x303030);
    }

    private void drawCooldownBar(GuiGraphics graphics) {
        int maxCd = Math.max(1, menu.getEffectiveCooldownTicks());
        int remaining = Math.max(0, menu.getCooldownTicks());
        float ratio = Mth.clamp((maxCd - remaining) / (float) maxCd, 0F, 1F);
        int fill = Math.round(ratio * BAR_INNER_W);

        int x0 = this.leftPos + BAR_CD_X + 1;
        int y0 = this.topPos + BAR_CD_Y + 1;
        graphics.fill(x0, y0, x0 + fill, y0 + BAR_INNER_H, 0xAA7D6BFF);

        String raw = (remaining <= 0)
                ? Component.translatable("gui.turretcraft.cooldown_zero").getString()
                : Component.translatable("gui.turretcraft.cooldown_ticks", remaining).getString();
        drawCenteredScaledText(graphics, raw,
                this.leftPos + BAR_CD_X + (BAR_W / 2),
                this.topPos + BAR_CD_Y,
                BAR_INNER_W,
                BAR_H,
                0x303030);
    }

    /**
     * Draw text at a consistent base size (scale=1.0), only scaling DOWN when it would overflow.
     * This keeps font size visually consistent across the GUI and across languages.
     */
    private void drawScaledText(GuiGraphics graphics, Component c, int x, int y, int maxWidth, int color) {
        String s = c == null ? "" : c.getString();
        int w = this.font.width(s);
        if (w <= maxWidth) {
            graphics.drawString(this.font, s, x, y, color, false);
            return;
        }
        float scale = Mth.clamp(maxWidth / (float) w, 0.35f, 1.0f);
        graphics.pose().pushPose();
        graphics.pose().translate(x, y, 0);
        graphics.pose().scale(scale, scale, 1.0f);
        graphics.drawString(this.font, s, 0, 0, color, false);
        graphics.pose().popPose();
    }

    private void drawCenteredScaledText(GuiGraphics graphics, String s, int centerX, int barY, int innerW, int barH, int color) {
        int w = this.font.width(s);
        float scale = 1.0f;
        if (w > innerW) {
            scale = Mth.clamp(innerW / (float) w, 0.35f, 1.0f);
        }
        // Use the font's lineHeight to keep sizing consistent with all other labels.
        float textH = this.font.lineHeight * scale;
        int ty = barY + Mth.floor((barH - textH) / 2.0f);

        graphics.pose().pushPose();
        graphics.pose().translate(centerX, ty, 0);
        graphics.pose().scale(scale, scale, 1.0f);
        graphics.drawString(this.font, s, -w / 2, 0, color, false);
        graphics.pose().popPose();
    }

    @Override
    protected void renderLabels(GuiGraphics graphics, int mouseX, int mouseY) {
        int lvl = menu.getUpgradeLevel();
        int range = menu.getEffectiveRange();
        float dmg = menu.getDamageMultiplier();
        float save = menu.getAmmoSaveChance() * 100.0F;

        // Keep all labels clipped to their half to avoid overlap at small UI scales.
        // We auto-scale (not ellipsis) so the full line is always visible.
        int leftW = 78;
        int rightW = 78;

        int x = 8;
        int y = 6;

        // Left column: keep it to TWO lines so it never overlaps the top buttons.
        // (Previously 3 lines would overlap with the button area at some UI scales.)
        drawScaledText(graphics,
                Component.translatable("gui.turretcraft.level", lvl, TurretUpgrades.MAX_LEVEL),
                x, y, leftW, 0x404040);
        y += 10;

        MutableComponent targetLine = Component.translatable("gui.turretcraft.target_mode",
                menu.isTargetPlayers()
                        ? Component.translatable("gui.turretcraft.target_players")
                        : Component.translatable("gui.turretcraft.target_monsters")).copy();
        targetLine.append(Component.literal("  "))
                .append(Component.translatable("gui.turretcraft.range", range));
        drawScaledText(graphics, targetLine, x, y, leftW, 0x404040);

        int rx = 90;
        int ry = 6;
        float base = menu.getTurretKind().damage();
        float real = base * dmg;

        drawScaledText(graphics,
                Component.translatable("gui.turretcraft.damage_value",
                        String.format("%.2f", real),
                        String.format("x%.2f", dmg)),
                rx, ry, rightW, 0x404040);
        ry += 10;

        drawScaledText(graphics,
                Component.translatable("gui.turretcraft.ammo_save", String.format("%.0f%%", save)),
                rx, ry, rightW, 0x404040);
    }


    @Override
    public void render(GuiGraphics graphics, int mouseX, int mouseY, float partialTicks) {
        this.renderBackground(graphics);
        super.render(graphics, mouseX, mouseY, partialTicks);

        this.renderTooltip(graphics, mouseX, mouseY);

        // Detailed upgrade tooltip (shows requirements + how-to)
        if (upgradeButton != null && upgradeButton.isMouseOver(mouseX, mouseY)) {
            int lvl = menu.getUpgradeLevel();
            if (lvl < TurretUpgrades.MAX_LEVEL) {
                List<TurretUpgrades.Requirement> req = menu.getNextRequirements();
                List<Component> lines = new ArrayList<>();
                lines.add(Component.translatable("tooltip.turretcraft.upgrade.header", lvl, lvl + 1));
                lines.add(Component.translatable("tooltip.turretcraft.upgrade.howto_icon"));
                lines.add(Component.empty());

                Container c = menu.getUpgradeContainer();
                for (TurretUpgrades.Requirement r : req) {
                    int have = countInUpgradeSlots(c, r.item());
                    MutableComponent itemName = Component.translatable(r.item().getDescriptionId());
                    lines.add(Component.translatable("tooltip.turretcraft.upgrade.line_have", itemName, have, r.count()));
                }

                List<FormattedCharSequence> seq = lines.stream().map(Component::getVisualOrderText).toList();
                graphics.renderTooltip(this.font, seq, mouseX, mouseY);
            } else {
                graphics.renderTooltip(this.font, Component.translatable("gui.turretcraft.max_level"), mouseX, mouseY);
            }
        }

        // Tooltips for upgrade slots (shows what each slot is for)
        if (isHovering(SLOT_IRON_X, SLOT_IRON_Y, 16, 16, mouseX, mouseY)) {
            graphics.renderTooltip(this.font, Component.translatable("tooltip.turretcraft.slot.iron"), mouseX, mouseY);
        } else if (isHovering(SLOT_FW_X, SLOT_FW_Y, 16, 16, mouseX, mouseY)) {
            graphics.renderTooltip(this.font, Component.translatable("tooltip.turretcraft.slot.firmware"), mouseX, mouseY);
        } else if (isHovering(SLOT_RED_X, SLOT_RED_Y, 16, 16, mouseX, mouseY)) {
            graphics.renderTooltip(this.font, Component.translatable("tooltip.turretcraft.slot.redstone"), mouseX, mouseY);
        } else if (isHovering(SLOT_GOLD_X, SLOT_GOLD_Y, 16, 16, mouseX, mouseY)) {
            graphics.renderTooltip(this.font, Component.translatable("tooltip.turretcraft.slot.gold"), mouseX, mouseY);
        } else if (isHovering(SLOT_DIAMOND_X, SLOT_DIAMOND_Y, 16, 16, mouseX, mouseY)) {
            graphics.renderTooltip(this.font, Component.translatable("tooltip.turretcraft.slot.diamond"), mouseX, mouseY);
        } else if (isHovering(SLOT_NETHER_X, SLOT_NETHER_Y, 16, 16, mouseX, mouseY)) {
            graphics.renderTooltip(this.font, Component.translatable("tooltip.turretcraft.slot.netherite"), mouseX, mouseY);
        }
    }

    private static int countInUpgradeSlots(Container c, Item item) {
        int total = 0;
        for (int i = 0; i < c.getContainerSize(); i++) {
            if (!c.getItem(i).isEmpty() && c.getItem(i).is(item)) {
                total += c.getItem(i).getCount();
            }
        }
        return total;
    }


    /**
     * Custom icon button with a subtle "breathing" glow.
     * Unique look to reduce the chance of colliding with common upgrade arrows/anvil icons.
     */
    private class UpgradeIconButton extends AbstractButton {
        private static final int W = 20;
        private static final int H = 20;

        UpgradeIconButton(int x, int y) {
            super(x, y, W, H, Component.empty());
        }

        @Override
        public void onPress() {
            if (TurretScreen.this.minecraft != null && TurretScreen.this.minecraft.gameMode != null) {
                TurretScreen.this.minecraft.gameMode.handleInventoryButtonClick(TurretScreen.this.menu.containerId, 2);
            }
        }

        @Override
        protected void renderWidget(GuiGraphics graphics, int mouseX, int mouseY, float partialTicks) {
            if (!this.visible) return;

            boolean hovered = mouseX >= this.getX() && mouseX < this.getX() + W && mouseY >= this.getY() && mouseY < this.getY() + H;

            // Base panel (dark, minimal)
            int x = this.getX();
            int y = this.getY();
            graphics.fill(x, y, x + W, y + H, 0x80303030);
            // Thin border for readability
            graphics.fill(x, y, x + W, y + 1, 0xA01A1A1A);
            graphics.fill(x, y + H - 1, x + W, y + H, 0xA01A1A1A);
            graphics.fill(x, y, x + 1, y + H, 0xA01A1A1A);
            graphics.fill(x + W - 1, y, x + W, y + H, 0xA01A1A1A);

            // Breathing glow (only when active + hovered)
            if (this.active && hovered) {
                long ms = Util.getMillis();
                // ~1.6s period, soft sine wave
                float t = (ms % 1600L) / 1600.0F;
                float pulse = 0.5F + 0.5F * Mth.sin(t * Mth.TWO_PI);
                // Alpha range: 0.12 ~ 0.38
                int a = (int) (30 + pulse * 70);
                int glow = (a << 24) | 0x2FB5B3; // TurretCraft accent (teal)
                graphics.fill(x - 1, y - 1, x + W + 1, y + H + 1, glow);
            }

            // Draw icon (unique rune-chip), 2 states: normal/hover
            int u = hovered ? 16 : 0;
            int ix = x + 2;
            int iy = y + 2;

            RenderSystem.enableBlend();
            if (!this.active) {
                RenderSystem.setShaderColor(1F, 1F, 1F, 0.45F);
            } else {
                RenderSystem.setShaderColor(1F, 1F, 1F, 1F);
            }
            graphics.blit(ICONS, ix, iy, u, 0, 16, 16, 32, 16);
            RenderSystem.setShaderColor(1F, 1F, 1F, 1F);
        }

        @Override
        protected void updateWidgetNarration(net.minecraft.client.gui.narration.NarrationElementOutput out) {
            out.add(net.minecraft.client.gui.narration.NarratedElementType.TITLE,
                    Component.translatable("button.turretcraft.upgrade_icon"));
        }
    }
}
