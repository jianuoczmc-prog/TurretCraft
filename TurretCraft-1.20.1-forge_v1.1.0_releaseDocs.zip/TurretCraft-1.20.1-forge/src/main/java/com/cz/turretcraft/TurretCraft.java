package com.cz.turretcraft;

import com.cz.turretcraft.registry.ModBlockEntities;
import com.cz.turretcraft.registry.ModBlocks;
import com.cz.turretcraft.registry.ModCreativeTabs;
import com.cz.turretcraft.registry.ModEntities;
import com.cz.turretcraft.registry.ModItems;
import com.cz.turretcraft.registry.ModMenus;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;

@Mod(TurretCraft.MODID)
public class TurretCraft {
    public static final String MODID = "turretcraft";

    public TurretCraft() {
        IEventBus modBus = FMLJavaModLoadingContext.get().getModEventBus();

        ModBlocks.BLOCKS.register(modBus);
        ModItems.ITEMS.register(modBus);
        ModBlockEntities.BLOCK_ENTITIES.register(modBus);
        ModEntities.ENTITY_TYPES.register(modBus);
        ModMenus.MENUS.register(modBus);
        ModCreativeTabs.TABS.register(modBus);
    }
}
