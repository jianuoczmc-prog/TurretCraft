package com.cz.turretcraft.registry;

import com.cz.turretcraft.TurretCraft;
import com.cz.turretcraft.block.TurretBlock;
import com.cz.turretcraft.block.TurretKind;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.material.MapColor;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModBlocks {
    public static final DeferredRegister<Block> BLOCKS = DeferredRegister.create(ForgeRegistries.BLOCKS, TurretCraft.MODID);

    private static final BlockBehaviour.Properties TURRET_PROPS = BlockBehaviour.Properties.of()
            .mapColor(MapColor.METAL)
            .strength(3.0F, 6.0F)
            .sound(SoundType.METAL)
            .requiresCorrectToolForDrops();

    public static final RegistryObject<Block> ARROW_TURRET = BLOCKS.register("arrow_turret", () -> new TurretBlock(TURRET_PROPS, TurretKind.ARROW));
    public static final RegistryObject<Block> FIRE_TURRET = BLOCKS.register("fire_turret", () -> new TurretBlock(TURRET_PROPS, TurretKind.FIRE));
    public static final RegistryObject<Block> LIGHTNING_TURRET = BLOCKS.register("lightning_turret", () -> new TurretBlock(TURRET_PROPS, TurretKind.LIGHTNING));
    public static final RegistryObject<Block> FROST_TURRET = BLOCKS.register("frost_turret", () -> new TurretBlock(TURRET_PROPS, TurretKind.FROST));

    public static final RegistryObject<Block> GATLING_TURRET = BLOCKS.register("gatling_turret", () -> new TurretBlock(TURRET_PROPS, TurretKind.GATLING));
    public static final RegistryObject<Block> POISON_TURRET = BLOCKS.register("poison_turret", () -> new TurretBlock(TURRET_PROPS, TurretKind.POISON));
    public static final RegistryObject<Block> CANNON_TURRET = BLOCKS.register("cannon_turret", () -> new TurretBlock(TURRET_PROPS, TurretKind.CANNON));
}
