package com.cz.turretcraft.block;

import com.cz.turretcraft.blockentity.TurretBlockEntity;
import com.cz.turretcraft.registry.ModBlockEntities;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.network.chat.Component;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.BaseEntityBlock;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.HorizontalDirectionalBlock;
import net.minecraft.world.level.block.RenderShape;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.NetworkHooks;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityTicker;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.DirectionProperty;
import net.minecraft.world.level.material.PushReaction;
import net.minecraft.world.phys.BlockHitResult;
import org.jetbrains.annotations.Nullable;

import java.util.UUID;

public class TurretBlock extends BaseEntityBlock {
    public static final DirectionProperty FACING = HorizontalDirectionalBlock.FACING;


    private final TurretKind kind;

    public TurretBlock(BlockBehaviour.Properties properties, TurretKind kind) {
        super(properties);
        this.kind = kind;
        this.registerDefaultState(this.stateDefinition.any().setValue(FACING, Direction.NORTH));
    }

    public TurretKind getKind() {
        return kind;
    }

    @Override
    public PushReaction getPistonPushReaction(BlockState state) {
        return PushReaction.BLOCK;
    }

    @Override
    public RenderShape getRenderShape(BlockState state) {
        // BaseEntityBlock defaults to INVISIBLE; we want to render the JSON block model.
        return RenderShape.MODEL;
    }

    @Override
    public BlockState getStateForPlacement(net.minecraft.world.item.context.BlockPlaceContext context) {
        return this.defaultBlockState().setValue(FACING, context.getHorizontalDirection().getOpposite());
    }

    @Override
    protected void createBlockStateDefinition(StateDefinition.Builder<net.minecraft.world.level.block.Block, BlockState> builder) {
        builder.add(FACING);
    }

    @Override
    public @Nullable BlockEntity newBlockEntity(BlockPos pos, BlockState state) {
        return new TurretBlockEntity(pos, state);
    }

    @Override
    public void setPlacedBy(Level level, BlockPos pos, BlockState state, @Nullable LivingEntity placer, ItemStack stack) {
        super.setPlacedBy(level, pos, state, placer, stack);
        if (level.isClientSide) return;
        if (placer instanceof Player player) {
            BlockEntity be = level.getBlockEntity(pos);
            if (be instanceof TurretBlockEntity turret) {
                UUID owner = player.getUUID();
                String teamName = player.getTeam() != null ? player.getTeam().getName() : null;
                turret.setOwner(owner, teamName);
                turret.setChanged();
            }
        }
    }

    @Override
    public @Nullable <T extends BlockEntity> BlockEntityTicker<T> getTicker(Level level, BlockState state, BlockEntityType<T> type) {
        return level.isClientSide ? createTickerHelper(type, ModBlockEntities.TURRET.get(), TurretBlockEntity::clientTick) : createTickerHelper(type, ModBlockEntities.TURRET.get(), TurretBlockEntity::serverTick);
    }

    @Override
    public InteractionResult use(BlockState state, Level level, BlockPos pos, Player player, InteractionHand hand, BlockHitResult hit) {
        if (level.isClientSide) {
            return InteractionResult.SUCCESS;
        }

        BlockEntity be = level.getBlockEntity(pos);
        if (!(be instanceof TurretBlockEntity turret)) {
            return InteractionResult.PASS;
        }

        ItemStack held = player.getItemInHand(hand);

        // Toggle targeting mode: sneak + stick (only owner).
        if (player.isShiftKeyDown() && held.is(Items.STICK)) {
            if (!turret.isOwner(player)) {
                player.displayClientMessage(Component.translatable("msg.turretcraft.not_owner"), true);
                return InteractionResult.CONSUME;
            }
            turret.toggleTargetPlayers();
            turret.setChanged();
            player.displayClientMessage(Component.translatable(turret.isTargetPlayers() ? "msg.turretcraft.target_players_on" : "msg.turretcraft.target_players_off"), true);
            return InteractionResult.CONSUME;
        }

        // Unload all ammo: sneak + empty hand.
        if (held.isEmpty() && player.isShiftKeyDown()) {
            int count = turret.getAmmo();
            if (count <= 0) {
                player.displayClientMessage(Component.translatable("msg.turretcraft.no_ammo"), true);
                return InteractionResult.CONSUME;
            }

            turret.setAmmo(0);
            turret.setChanged();

            while (count > 0) {
                int give = Math.min(64, count);
                count -= give;
                ItemStack giveStack = turret.createAmmoStack(give);
                if (!player.addItem(giveStack)) {
                    player.drop(giveStack, false);
                }
            }

            turret.clearAmmoTemplateIfEmpty();

            player.displayClientMessage(Component.translatable("msg.turretcraft.unloaded"), true);
            return InteractionResult.CONSUME;
        }

        // Quick load ammo: right-click with ammo item.
        // (Arrow turret accepts any ArrowItem including tipped/spectral; only one arrow type at a time.)
        if (!held.isEmpty()) {
            int before = held.getCount();
            int consumed = turret.addAmmoFromStack(held);
            if (consumed > 0) {
                player.displayClientMessage(Component.translatable("msg.turretcraft.loaded", consumed, turret.getAmmo(), turret.getMaxAmmo()), true);
                return InteractionResult.CONSUME;
            } else if (turret.getAmmo() >= turret.getMaxAmmo() && before > 0) {
                player.displayClientMessage(Component.translatable("msg.turretcraft.ammo_full", turret.getMaxAmmo()), true);
                return InteractionResult.CONSUME;
            }
        }

        // Open GUI
        if (player instanceof ServerPlayer sp) {
            NetworkHooks.openScreen(sp, turret, pos);
        }
        return InteractionResult.CONSUME;
    }
    @Override
    public boolean hasAnalogOutputSignal(BlockState state) {
        return true;
    }

    @Override
    public int getAnalogOutputSignal(BlockState state, Level level, BlockPos pos) {
        BlockEntity be = level.getBlockEntity(pos);
        if (be instanceof TurretBlockEntity turret) {
            // Redstone comparator output: 0..15 based on ammo fill.
            float pct = Math.min(1.0F, turret.getAmmo() / (float) turret.getMaxAmmo());
            return Math.round(pct * 15.0F);
        }
        return 0;
    }

    @Override
    public net.minecraft.world.phys.shapes.VoxelShape getShape(BlockState state, BlockGetter level, BlockPos pos, net.minecraft.world.phys.shapes.CollisionContext context) {
        // Slightly shorter than full cube.
        return Block.box(0, 0, 0, 16, 14, 16);
    }
}
