package com.cz.turretcraft.client;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screens.inventory.BookViewScreen;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;

/**
 * Client-only helper for the manual.
 *
 * Written books use a plain string for the title (it is NOT translatable).
 * To keep a "proper" title in each language, we set the title right before
 * opening the book on the client.
 */
public final class ManualClientHelper {
    private ManualClientHelper() {}

    public static void localizeBookTitle(ItemStack stack) {
        if (stack == null || stack.isEmpty()) return;
        CompoundTag tag = stack.getOrCreateTag();

        String code = "en_us";
        try {
            // 1.20.1: language codes look like "en_us", "zh_cn", "zh_tw", "ja_jp".
            code = Minecraft.getInstance().getLanguageManager().getSelected();
        } catch (Throwable ignored) {
        }

        String title;
        switch (code) {
            case "zh_cn" -> title = "炮塔说明书";
            case "zh_tw" -> title = "砲塔說明書";
            case "ja_jp" -> title = "タレット説明書";
            default -> title = "Turret Manual";
        }

        tag.putString("title", title);
        tag.putString("filtered_title", title);
    }

    /**
     * Open the manual as a vanilla written book screen.
     *
     * Important: we must wrap the manual's NBT into an actual Items.WRITTEN_BOOK stack,
     * otherwise the client won't treat a custom book item as openable.
     */
    public static void openManual(ItemStack manualStack) {
        if (manualStack == null || manualStack.isEmpty()) return;

        Minecraft mc = Minecraft.getInstance();
        if (mc == null) return;

        ItemStack tempWrittenBook = new ItemStack(Items.WRITTEN_BOOK);
        CompoundTag tag = manualStack.getTag();
        if (tag != null) {
            tempWrittenBook.setTag(tag.copy());
        }

        mc.setScreen(new BookViewScreen(BookViewScreen.BookAccess.fromItem(tempWrittenBook)));
    }
}
