package com.cz.turretcraft.registry;

import com.cz.turretcraft.TurretCraft;
import com.cz.turretcraft.block.TurretBlockItem;
import com.cz.turretcraft.item.TurretFirmwareItem;
import com.cz.turretcraft.item.TurretManualItem;
import net.minecraft.world.item.Item;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModItems {
    public static final DeferredRegister<Item> ITEMS = DeferredRegister.create(ForgeRegistries.ITEMS, TurretCraft.MODID);

    // Upgrade items
    public static final RegistryObject<Item> TURRET_FIRMWARE = ITEMS.register("turret_firmware", () -> new TurretFirmwareItem(new Item.Properties()));
    public static final RegistryObject<Item> TURRET_MANUAL = ITEMS.register("turret_manual", () -> new TurretManualItem(new Item.Properties().stacksTo(1)));

    // Ammo item for Frost Turret.
    public static final RegistryObject<Item> FROST_SHARD = ITEMS.register("frost_shard", () -> new Item(new Item.Properties()));

    // Extra ammo types
    public static final RegistryObject<Item> IRON_BULLET = ITEMS.register("iron_bullet", () -> new Item(new Item.Properties()));
    public static final RegistryObject<Item> POISON_DART = ITEMS.register("poison_dart", () -> new Item(new Item.Properties()));
    public static final RegistryObject<Item> CANNONBALL = ITEMS.register("cannonball", () -> new Item(new Item.Properties()));

    // Block items
    public static final RegistryObject<Item> ARROW_TURRET = ITEMS.register("arrow_turret", () -> new TurretBlockItem(ModBlocks.ARROW_TURRET.get(), new Item.Properties()));
    public static final RegistryObject<Item> FIRE_TURRET = ITEMS.register("fire_turret", () -> new TurretBlockItem(ModBlocks.FIRE_TURRET.get(), new Item.Properties()));
    public static final RegistryObject<Item> LIGHTNING_TURRET = ITEMS.register("lightning_turret", () -> new TurretBlockItem(ModBlocks.LIGHTNING_TURRET.get(), new Item.Properties()));
    public static final RegistryObject<Item> FROST_TURRET = ITEMS.register("frost_turret", () -> new TurretBlockItem(ModBlocks.FROST_TURRET.get(), new Item.Properties()));

    public static final RegistryObject<Item> GATLING_TURRET = ITEMS.register("gatling_turret", () -> new TurretBlockItem(ModBlocks.GATLING_TURRET.get(), new Item.Properties()));
    public static final RegistryObject<Item> POISON_TURRET = ITEMS.register("poison_turret", () -> new TurretBlockItem(ModBlocks.POISON_TURRET.get(), new Item.Properties()));
    public static final RegistryObject<Item> CANNON_TURRET = ITEMS.register("cannon_turret", () -> new TurretBlockItem(ModBlocks.CANNON_TURRET.get(), new Item.Properties()));
}
